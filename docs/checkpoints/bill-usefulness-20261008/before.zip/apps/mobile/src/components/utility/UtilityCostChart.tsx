import { Feather } from "@expo/vector-icons";
import { useState } from "react";
import { Pressable, Text, View } from "react-native";
import { Surface } from "@/components/ui/Surface";
import { formatDueDate, type UtilityInsight } from "@/lib/bills-data";
import { colors, spacing, typography } from "@/theme/tokens";

const money = (value: number) => new Intl.NumberFormat("en-CA", { style: "currency", currency: "CAD" }).format(value);

export function UtilityCostChart({ insight, onOpenStatement }: { insight: UtilityInsight; onOpenStatement: (id: string) => void }) {
 const [selectedId, setSelectedId] = useState<string | null>(null);
 const points = insight.history.filter(point => typeof point.amount === "number" && Number.isFinite(point.amount));
 if (!points.length) return null;
 const selected = points.find(point => point.billId === selectedId) ?? points[points.length - 1];
 const selectedIndex = points.indexOf(selected);
 const max = Math.max(...points.map(point => Math.abs(point.amount!)), 1);
 return <View style={{ gap: spacing.md }}>
  <View style={{ gap: 3 }}>
   <Text style={[typography.section, { color: colors.foreground }]}>Bill trend</Text>
   <Text style={[typography.caption, { color: colors.mutedForeground }]}>Last {points.length} saved {points.length === 1 ? "statement" : "statements"} · Tap a bar to explore</Text>
  </View>
  <Surface tone="subtle" style={{ gap: spacing.md }}>
   <View style={{ height: 146, flexDirection: "row", alignItems: "flex-end", gap: 4 }}>
    {points.map((point, index) => <Pressable key={point.billId}
     accessibilityRole="button" accessibilityLabel={`${point.label}, ${money(point.amount!)}${point.amount! < 0 ? ", credit" : ""}`}
     accessibilityHint="Show this statement’s amount and billing period" accessibilityState={{ selected: point.billId === selected.billId }}
     onPress={() => setSelectedId(point.billId)}
     style={{ flex: 1, height: "100%", alignItems: "center", justifyContent: "flex-end", gap: 6 }}>
     <View style={{ width: "100%", maxWidth: 26, height: Math.max(4, Math.abs(point.amount!) / max * 118), borderRadius: 6, backgroundColor: point.billId === selected.billId ? colors.primary : colors.border }} />
     {index === 0 || index === points.length - 1 || points.length <= 4
      ? <Text numberOfLines={1} style={{ fontSize: 10, color: colors.mutedForeground }}>{point.label.split(" ")[0]}</Text>
      : <View style={{ height: 12 }} />}
    </Pressable>)}
   </View>
   <View style={{ borderTopWidth: 1, borderColor: colors.border, paddingTop: spacing.md, gap: spacing.sm }}>
    <View style={{ flexDirection: "row", alignItems: "center", gap: spacing.sm }}>
     <View accessibilityLiveRegion="polite" style={{ flex: 1, gap: 3 }}>
      <Text style={[typography.caption, { color: colors.mutedForeground }]}>{selected.label}{selected.amount! < 0 ? " · Credit" : ""}</Text>
      <Text style={[typography.section, { color: colors.foreground }]}>{money(selected.amount!)} <Text style={typography.caption}>CAD</Text></Text>
     </View>
     {([-1, 1] as const).map(direction => {
      const next = points[selectedIndex + direction];
      return <Pressable key={direction} accessibilityRole="button" accessibilityLabel={direction < 0 ? "Previous statement" : "Next statement"} accessibilityState={{ disabled: !next }} disabled={!next}
       onPress={() => next && setSelectedId(next.billId)} style={{ width: 44, height: 44, alignItems: "center", justifyContent: "center", opacity: next ? 1 : 0.3 }}>
       <Feather name={direction < 0 ? "chevron-left" : "chevron-right"} size={20} color={colors.primary} />
      </Pressable>;
     })}
    </View>
    <Text style={[typography.caption, { color: colors.mutedForeground }]}>{selected.periodStart && selected.periodEnd ? `${formatDueDate(selected.periodStart)} – ${formatDueDate(selected.periodEnd)}` : "Billing dates unavailable"}</Text>
    <Pressable accessibilityRole="button" accessibilityLabel={`View ${selected.label} statement`} onPress={() => onOpenStatement(selected.billId)} style={{ minHeight: 44, flexDirection: "row", alignItems: "center", gap: 8 }}>
     <Text style={[typography.body, { color: colors.primary, fontWeight: "600" }]}>View statement</Text><Feather name="arrow-right" size={16} color={colors.primary}/>
    </Pressable>
   </View>
   {points.some(point => point.amount! < 0) ? <Text style={[typography.caption, { color: colors.mutedForeground }]}>Bar height shows the size of each amount. Credits are labelled with a minus sign.</Text> : null}
  </Surface>
 </View>;
}
