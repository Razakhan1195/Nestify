import { Feather } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { useEffect, useMemo, useState } from "react";
import { ActivityIndicator, Pressable, ScrollView, Text, TextInput, View } from "react-native";
import { Button } from "./Button";
import { QuietAction } from "./Brief";
import { Surface } from "./ui/Surface";
import { fetchProviderConnections, type ProviderDirectoryEntry } from "@/lib/provider-data";
import { findDirectoryEntries, providerServiceFilters, type ProviderServiceFilter } from "@/lib/provider-directory";
import { colors, spacing, typography } from "@/theme/tokens";

const label = { green_button: "Connect · Green Button", deck: "Connect · Deck", coming_soon: "Coming soon" };
export function ProviderFinder() {
  const router = useRouter();
  const [entries, setEntries] = useState<ProviderDirectoryEntry[]>([]);
  const [query, setQuery] = useState("");
  const [service, setService] = useState<ProviderServiceFilter>("All");
  const [selected, setSelected] = useState<ProviderDirectoryEntry | null>(null);
  const [loading, setLoading] = useState(true);
  const [failed, setFailed] = useState(false);
  const [attempt, setAttempt] = useState(0);
  const [limit, setLimit] = useState(30);
  useEffect(() => {
    let active = true;
    fetchProviderConnections().then(payload => {
      if (!active) return;
      if (payload.needsOnboarding) { router.replace("/onboarding" as never); return; }
      if (!payload.directory) throw Error("Directory unavailable");
      setEntries(payload.directory);
    }).catch(() => { if (active) setFailed(true); }).finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [attempt, router]);
  const matches = useMemo(() => findDirectoryEntries(entries, query, service), [entries, query, service]);
  function choose(entry: ProviderDirectoryEntry) {
    if (entry.method === "green_button") router.push({ pathname: "/provider/ezgb", params: { utilityName: entry.greenButtonName ?? entry.name } });
    else if (entry.method === "deck" && entry.registryProviderId) router.push({ pathname: "/provider/deck", params: { registryProviderId: entry.registryProviderId } });
    else setSelected(entry);
  }
  if (selected) return <Surface tone="raised" style={{ gap: spacing.md }}>
      <Text accessibilityRole="header" style={[typography.section, { color: colors.foreground }]}>{selected.name}</Text>
      <Text style={[typography.meta, { color: colors.mutedForeground }]}>{selected.category} · Coming soon</Text>
      <Text style={[typography.body, { color: colors.mutedForeground }]}>{selected.name === "Rogers" ? "We’re still testing Rogers sign-in. You can upload your statements in the meantime." : "An automatic connection isn’t available for this bill yet. Upload a statement to keep your bills and history together."}</Text>
      <Button label="Upload a statement" onPress={() => router.push("/bill/batch")} />
      <QuietAction label="Back to results" onPress={() => setSelected(null)} />
    </Surface>;
  return <View style={{ gap: spacing.lg }}>
    <View style={{ gap: spacing.sm }}>
      <Text accessibilityRole="header" style={[typography.heading, { color: colors.foreground }]}>Find your provider</Text>
      <Text style={[typography.body, { color: colors.mutedForeground }]}>Search your company or municipality. We’ll choose the connection that fits your bill.</Text>
    </View>
    <View style={{ gap: spacing.sm }}>
      <View style={{ flexDirection: "row", alignItems: "center", gap: spacing.sm, borderWidth: 1, borderColor: colors.borderStrong, borderRadius: 12, paddingHorizontal: spacing.md, backgroundColor: colors.surfaceRaised }}>
        <Feather name="search" size={19} color={colors.mutedForeground} />
        <TextInput accessibilityLabel="Search providers across Canada" value={query} onChangeText={value => { setQuery(value); setSelected(null); setLimit(30); }} placeholder="Company or municipality" placeholderTextColor={colors.mutedForeground} autoCorrect={false} style={[typography.body, { flex: 1, minHeight: 52, color: colors.foreground }]} />
        {query ? <Pressable accessibilityRole="button" accessibilityLabel="Clear search" onPress={() => { setQuery(""); setLimit(30); }} style={{ minWidth: 44, minHeight: 44, justifyContent: "center", alignItems: "center" }}><Feather name="x" size={18} color={colors.primary} /></Pressable> : null}
      </View>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: spacing.sm }}>
        {providerServiceFilters.map(value => <Pressable key={value} accessibilityRole="button" accessibilityState={{ selected: service === value }} onPress={() => { setService(value); setSelected(null); setLimit(30); }} style={{ minHeight: 44, justifyContent: "center", paddingHorizontal: 14, borderRadius: 22, backgroundColor: value === service ? colors.primary : colors.surfaceRaised, borderWidth: 1, borderColor: colors.border }}>
          <Text style={[typography.meta, { color: value === service ? colors.primaryForeground : colors.foreground }]}>{value}</Text>
        </Pressable>)}
      </ScrollView>
    </View>
    <Surface tone="subtle" style={{ gap: spacing.sm }}>
      <Text style={[typography.meta, { color: colors.foreground, fontWeight: "600" }]}>One search. The right connection.</Text>
      <Text style={[typography.meta, { color: colors.mutedForeground }]}>For supported Ontario electricity and gas, we recommend Green Button to share bills and energy usage. Other available bill connections use Deck’s secure sign-in.</Text>
      <Text style={[typography.caption, { color: colors.mutedForeground }]}>Water is listed separately. Coming soon means sign-in isn’t available yet; you can upload bills today.</Text>
    </Surface>
    {loading ? <ActivityIndicator accessibilityLabel="Loading provider directory" color={colors.primary} /> : failed ? <View style={{ gap: spacing.sm }}>
      <Text accessibilityRole="alert" style={[typography.body, { color: colors.foreground }]}>We couldn’t load provider availability. Try again or upload your bill.</Text>
      <QuietAction label="Try again" onPress={() => { setLoading(true); setFailed(false); setAttempt(value => value + 1); }} />
    </View> : <View>
      <Text style={[typography.caption, { color: colors.mutedForeground, marginBottom: spacing.sm }]}>{matches.length} {matches.length === 1 ? "result" : "results"} across Canada · Connections available for your place appear first</Text>
      {matches.slice(0, limit).map(entry => <Pressable key={entry.id} accessibilityRole="button" accessibilityLabel={entry.name + ". " + entry.category + ". " + label[entry.method]} onPress={() => choose(entry)} style={({ pressed }) => ({ paddingVertical: spacing.lg, borderBottomWidth: 1, borderBottomColor: colors.border, flexDirection: "row", alignItems: "center", gap: spacing.md, opacity: pressed ? 0.7 : 1 })}>
        <View style={{ flex: 1, gap: 5 }}>
          <Text style={[typography.body, { fontWeight: "600", color: colors.foreground }]}>{entry.name}</Text>
          <Text style={[typography.meta, { color: colors.mutedForeground }]}>{entry.category}{entry.provinces.length ? " · " + entry.provinces.join(", ") : ""}</Text>
          <Text style={[typography.caption, { color: entry.method === "coming_soon" ? colors.mutedForeground : colors.primary }]}>{label[entry.method]}{entry.method === "green_button" ? " · Recommended" : ""}</Text>
        </View>
        <Feather name="chevron-right" size={18} color={colors.mutedForeground} />
      </Pressable>)}
      {!matches.length ? <Text style={[typography.body, { color: colors.foreground, marginVertical: spacing.md }]}>No match yet. Try the company name printed on your bill, or choose All bill types. You can still upload any Canadian statement.</Text> : null}
      {matches.length > limit ? <QuietAction label="Show more providers" onPress={() => setLimit(value => value + 50)} /> : null}
    </View>}
    <View style={{ gap: spacing.sm }}>
      <QuietAction label="Upload a statement instead" onPress={() => router.push("/bill/batch")} />
      <Text style={[typography.caption, { color: colors.mutedForeground }]}>We’re expanding connections across Canada. Local municipal and home-service listings are still growing; a listing doesn’t mean sign-in has passed testing.</Text>
    </View>
  </View>;
}
