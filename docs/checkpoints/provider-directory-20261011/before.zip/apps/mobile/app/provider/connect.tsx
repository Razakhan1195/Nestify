import { Redirect, useLocalSearchParams, useRouter } from "expo-router";
import { ScrollView, Text } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { ScreenNavigation } from "@/components/ScreenNavigation";
import { ProviderConnectionChoices } from "@/components/ProviderConnectionChoices";
import { QuietAction } from "@/components/Brief";
import { colors, layout, typography } from "@/theme/tokens";

export default function ConnectProviderScreen() {
  const { providerId } = useLocalSearchParams<{ providerId?: string }>();
  const router = useRouter();
  if (providerId) return <Redirect href={{ pathname: "/provider/deck", params: { providerId } }} />;
  return <SafeAreaView style={{ flex: 1, backgroundColor: colors.canvas }}>
    <ScreenNavigation title="Connect a provider" fallback="/(tabs)/bills" />
    <ScrollView contentContainerStyle={{ padding: layout.screenHorizontal, gap: 24, paddingBottom: 32 }}>
      <Text style={[typography.body, { color: colors.mutedForeground }]}>Choose how to connect. You can always upload a bill instead.</Text>
      <ProviderConnectionChoices />
      <QuietAction label="Upload a statement instead" onPress={() => router.push("/bill/batch")} />
    </ScrollView>
  </SafeAreaView>;
}
