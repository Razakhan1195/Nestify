import {ConnectionBrand} from "@/components/ConnectionBrand";
import {ezgbBillsAvailable,ezgbProgress} from "@/lib/ezgb-progress";
import { UtilityConnectionOutcome } from "@/components/UtilityConnectionOutcome";
import {NavigationButton} from "@/components/NavigationButton";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useCallback, useEffect, useRef, useState } from "react";
import {
  ActivityIndicator,
  Linking,
  ScrollView,
  Text,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { WebView, type WebViewMessageEvent } from "react-native-webview";

import { QuietAction } from "@/components/Brief";
import { Button } from "@/components/Button";
import { Surface } from "@/components/ui/Surface";
import { ApiError } from "@/lib/api";
import {
  fetchEzgbAuthorization,
  fetchEzgbSyncStatus,
  syncEzgb,
  type EzgbAuthorizationPayload,
  type EzgbSyncPayload,
} from "@/lib/ezgb-data";
import { colors, layout, spacing, typography } from "@/theme/tokens";
import { safeBack } from "@/lib/navigation";

type Stage =
  | "intro"
  | "loading"
  | "authorizing"
  | "syncing"
  | "complete"
  | "authorized_pending"
  | "error";

const MAX_STATUS_ATTEMPTS = 60;
const STATUS_INTERVAL_MS = 5_000;

function delay(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export default function EzgbConnectionScreen() {
  const router = useRouter();
  const { resume } = useLocalSearchParams<{ resume?: string }>();
  const [authorization, setAuthorization] =
    useState<EzgbAuthorizationPayload | null>(null);
  const [stage, setStage] = useState<Stage>(resume ? "loading" : "intro");
  const [error, setError] = useState<string | null>(null);
  const [syncResult, setSyncResult] = useState<EzgbSyncPayload | null>(null);
  const syncInFlight = useRef(false);
  const cancelled = useRef(false);

  const [started, setStarted] = useState(false);
  useEffect(() => {
    if (!started) return;
    cancelled.current = false;
    fetchEzgbAuthorization()
      .then((payload) => {
        if (cancelled.current) return;
        setAuthorization(payload);
        setStage("authorizing");
      })
      .catch((loadError) => {
        if (cancelled.current) return;
        setError(
          loadError instanceof ApiError
            ? loadError.message
            : "Could not start the utility connection.",
        );
        setStage("error");
      });

    return () => {
      cancelled.current = true;
    };
  }, [started]);

  const runSync = useCallback(async (restore = false) => {
    if (syncInFlight.current) return;
    syncInFlight.current = true;
    setError(null);
    setStage("syncing");

    try {
      const started = restore ? await fetchEzgbSyncStatus() : await syncEzgb();
      if (cancelled.current) return;

      setSyncResult(started);
      if (started.ready || ezgbBillsAvailable(started)) {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        setStage("complete");
        return;
      }

      if (started.status === "idle") { setStage("intro"); return; }
      if (started.status === "failed") { setError(started.error ?? "The import could not finish. Your saved bills remain available."); setStage("error"); return; }
      if (started.status === "waiting") { setStage("authorized_pending"); return; }
      if (!started.jobId) {
        setStage("authorized_pending");
        return;
      }

      for (let attempt = 0; attempt < MAX_STATUS_ATTEMPTS; attempt += 1) {
        await delay(STATUS_INTERVAL_MS);
        if (cancelled.current) return;

        const result = await fetchEzgbSyncStatus(started.jobId);
        if (cancelled.current) return;
        setSyncResult(result);

        if (result.ready || ezgbBillsAvailable(result)) {
          Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
          setStage("complete");
          return;
        }

        if (result.status === "failed") {
          setError(result.error ?? "The utility connection needs another try.");
          setStage("error");
          return;
        }

        if (result.status === "waiting") {
          setStage("authorized_pending");
          return;
        }
      }

      if (!cancelled.current) setStage("authorized_pending");
    } catch (syncError) {
      if (!cancelled.current) {
        setError(
          syncError instanceof ApiError
            ? syncError.message
            : "Your utility was authorized, but Rezlee could not retrieve the data yet.",
        );
        setStage("authorized_pending");
      }
    } finally {
      syncInFlight.current = false;
    }
  }, []);

  useEffect(() => {
    cancelled.current = false;
    const timer = resume ? setTimeout(() => void runSync(true), 0) : undefined;
    return () => { cancelled.current = true; clearTimeout(timer); };
  }, [resume, runSync]);

  function handleMessage(event: WebViewMessageEvent) {
    try {
      const payload = JSON.parse(event.nativeEvent.data) as { type?: string };
      if (payload.type === "ezgb_authorized") {
        void runSync();
      } else if (payload.type === "ezgb_error") {
        setError("The utility authorization was not completed.");
        setStage("error");
      }
    } catch {
      // Ignore messages that are not from Rezlee's callback pages.
    }
  }

  function handleNavigation(url: string) {
    if (url.includes("/integrations/ezgb/success")) {
      void runSync();
    } else if (url.includes("/integrations/ezgb/error")) {
      setError("The utility authorization was not completed.");
      setStage("error");
    }
  }

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
      <View
        style={{
          minHeight: 54,
          paddingHorizontal: layout.screenHorizontal,
          flexDirection: "row",
          alignItems: "center",
          justifyContent: "space-between",
        }}
      >
        <NavigationButton onPress={() => safeBack(router, "/provider/connect")} label="Close" close/>
        <Text style={{ fontSize: 15, fontWeight: "700", color: colors.foreground }}>
          Connect an Ontario utility
        </Text>
        <View style={{ width: 44 }} />
      </View>

      {stage === "intro" ? (
        <ScrollView contentContainerStyle={{ padding: layout.screenHorizontal, gap: spacing.lg }}>
          <ConnectionBrand kind="green"/>
          <Text style={[typography.meta, { color: colors.primary }]}>Powered by EZGB</Text>
          <Text accessibilityRole="header" style={[typography.heading, { color: colors.foreground }]}>Your energy data, with your permission</Text>
          <Text style={[typography.body, { color: colors.mutedForeground }]}>Connect a supported Ontario electricity or natural gas account to bring available bills and usage into Rezlee. Data and history vary by utility.</Text>
          <Surface tone="subtle" style={{ gap: spacing.md }}>
            <Text style={[typography.section, { color: colors.foreground }]}>How sharing works</Text>
            <Text style={[typography.body, { color: colors.mutedForeground }]}>Green Button is the energy-data sharing standard used by Ontario utilities. EZGB / Screaming Power provides the connection and retrieves the data you authorize.</Text>
            <Text style={[typography.body, { color: colors.mutedForeground }]}>You will choose your utility and follow its authorization process. Rezlee does not ask you to enter a utility password in a Rezlee login form for this connection.</Text>
            <Text style={[typography.body, { color: colors.mutedForeground }]}>Review the utility and EZGB terms before approving. You can revoke data-sharing consent through your utility; previously saved records in Rezlee are separate.</Text>
          </Surface>
          <Text style={[typography.meta, { color: colors.mutedForeground }]}>Scheduled updates are not enabled yet. Connecting does not currently mean your bills will refresh every month.</Text>
          <Button label="Choose my Ontario utility" onPress={() => { setStage("loading"); setStarted(true); }} />
          <View style={{ gap: spacing.xs }}>
            <Text style={[typography.section, { color: colors.foreground }]}>Outside Ontario?</Text>
            <Text style={[typography.body, { color: colors.mutedForeground }]}>Connections in more provinces are planned. You can upload your Canadian bills now and review your recorded charges.</Text>
            <QuietAction label="Upload a bill instead" onPress={() => router.replace("/bill/batch")} />
            <QuietAction label="Read the Ontario Energy Board’s Green Button guide" onPress={() => {
              void Linking.openURL("https://www.oeb.ca/consumer-information-and-protection/green-button").catch(() => setError("Couldn’t open the guide. You can try again."));
            }} />
            {error ? <Text accessibilityRole="alert" style={[typography.meta, { color: colors.criticalForeground }]}>{error}</Text> : null}
          </View>
        </ScrollView>
      ) : stage === "loading" ? (
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center", gap: spacing.md }}>
          <ActivityIndicator color={colors.primary} />
          <Text style={[typography.body, { color: colors.mutedForeground }]}>
            Preparing secure connection…
          </Text>
        </View>
      ) : stage === "authorizing" && authorization ? (
        <View style={{ flex: 1 }}>
          <View style={{ paddingHorizontal: layout.screenHorizontal, paddingBottom: spacing.md }}>
            <Text style={[typography.caption, { color: colors.mutedForeground, lineHeight: 18 }]}>
              Choose a supported Ontario electricity or natural gas utility. Review the utility and EZGB consent terms before approving data sharing.
            </Text>
          </View>
          <WebView
            source={{ uri: authorization.authorizationUrl }}
            onMessage={handleMessage}
            onNavigationStateChange={(nav) => handleNavigation(nav.url)}
            javaScriptEnabled
            domStorageEnabled
            sharedCookiesEnabled
            thirdPartyCookiesEnabled
            startInLoadingState
            renderLoading={() => (
              <View
                style={{
                  position: "absolute",
                  inset: 0,
                  alignItems: "center",
                  justifyContent: "center",
                  backgroundColor: colors.background,
                }}
              >
                <ActivityIndicator color={colors.primary} />
              </View>
            )}
          />
        </View>
      ) : (
        <ScrollView
          contentContainerStyle={{
            flexGrow: 1,
            paddingHorizontal: layout.screenHorizontal,
            paddingTop: spacing["2xl"],
            paddingBottom: spacing.xl,
            gap: spacing.lg,
          }}
        >
          {stage === "syncing" ? (
            <>
              <View
                style={{
                  width: 52,
                  height: 52,
                  borderRadius: 26,
                  alignItems: "center",
                  justifyContent: "center",
                  backgroundColor: colors.accent,
                }}
              >
                <ActivityIndicator color={colors.primary} />
              </View>
              <View style={{ gap: spacing.sm }}>
                <Text style={[typography.heading, { color: colors.foreground }]}>
                  Retrieving your utility data
                </Text>
                <Text style={[typography.body, { color: colors.mutedForeground, lineHeight: 22 }]}>
                  Authorization is complete. EZGB is retrieving your Green Button data and Rezlee is preparing your bills.
                </Text>
              </View>
              <Surface tone="subtle">
                <Text style={[typography.caption, { color: colors.mutedForeground, lineHeight: 18 }]}>
                  This first retrieval can take up to a few minutes. You can leave Rezlee — the secure retrieval will keep running on our server.
                </Text>
              </Surface>
            </>
          ) : stage === "complete" ? (
            <>
              <View
                style={{
                  width: 52,
                  height: 52,
                  borderRadius: 26,
                  alignItems: "center",
                  justifyContent: "center",
                  backgroundColor: colors.successBg,
                }}
              >
                <Feather name="check" size={22} color={colors.successForeground} />
              </View>
              <View style={{ gap: spacing.sm }}>
                <Text style={[typography.heading, { color: colors.foreground }]}>
                  Utility connected
                </Text>
                <Text style={[typography.body, { color: colors.mutedForeground, lineHeight: 22 }]}>
                  This retrieval saved or updated {syncResult?.stats.billsImported ?? 0} bill record{(syncResult?.stats.billsImported ?? 0) === 1 ? "" : "s"}.
                </Text>
              </View>
              <UtilityConnectionOutcome />
              <Button
                label="View bills"
                onPress={() => router.replace("/(tabs)/bills")}
              />
            </>
          ) : stage === "authorized_pending" ? (
            <>
              <View
                style={{
                  width: 52,
                  height: 52,
                  borderRadius: 26,
                  alignItems: "center",
                  justifyContent: "center",
                  backgroundColor: colors.infoBg,
                }}
              >
                <Feather name="clock" size={21} color={colors.infoForeground} />
              </View>
              <View style={{ gap: spacing.sm }}>
                <Text style={[typography.heading, { color: colors.foreground }]}>
                  {syncResult ? ezgbProgress(syncResult)?.title : "Your bills aren’t ready yet"}
                </Text>
                <Text style={[typography.body, { color: colors.mutedForeground, lineHeight: 22 }]}>
                  {syncResult ? ezgbProgress(syncResult)?.detail : "Check the saved import status to see whether your statements have arrived."}
                </Text>
              </View>
              {error ? (
                <Surface tone="subtle">
                  <Text style={[typography.caption, { color: colors.mutedForeground }]}>
                    {error}
                  </Text>
                </Surface>
              ) : null}
              <Button label="Try import again" onPress={() => void runSync()} />
              <QuietAction label="Check status" onPress={() => void runSync(true)} />
              <Button
                label="Go back to Bills"
                variant="secondary"
                onPress={() => router.replace("/(tabs)/bills")}
              />
            </>
          ) : (
            <>
              <View
                style={{
                  width: 52,
                  height: 52,
                  borderRadius: 26,
                  alignItems: "center",
                  justifyContent: "center",
                  backgroundColor: colors.criticalBg,
                }}
              >
                <Feather name="alert-circle" size={21} color={colors.criticalForeground} />
              </View>
              <View style={{ gap: spacing.sm }}>
                <Text style={[typography.heading, { color: colors.foreground }]}>
                  Your bill import didn’t finish
                </Text>
                <Text style={[typography.body, { color: colors.mutedForeground, lineHeight: 22 }]}>
                  {error ?? "Return to Bills and try the connection again."}
                </Text>
              </View>
              {syncResult ? <Button label="Try import again" onPress={() => void runSync()} /> : null}
              <Button
                variant="secondary"
                label="Back to Bills"
                onPress={() => router.replace("/(tabs)/bills")}
              />
            </>
          )}
        </ScrollView>
      )}
    </SafeAreaView>
  );
}
