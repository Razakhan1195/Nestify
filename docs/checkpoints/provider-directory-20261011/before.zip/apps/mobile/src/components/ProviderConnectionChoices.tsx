import { useRouter } from "expo-router";
import { View } from "react-native";
import { OntarioUtilityConnection } from "@/components/OntarioUtilityConnection";
import {ProviderConnectionCard} from "./ProviderConnectionCard";

export function ProviderConnectionChoices() {
  const router = useRouter();
  return <View style={{ gap: 12 }}>
    <OntarioUtilityConnection onPress={() => router.push("/provider/ezgb")} />
    <ProviderConnectionCard kind="deck" onPress={()=>router.push("/provider/deck")}/>
  </View>;
}
