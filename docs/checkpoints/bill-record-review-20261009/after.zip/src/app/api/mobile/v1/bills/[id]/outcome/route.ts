import {effectiveBillTable} from "@/lib/product/bill-records";
import { randomUUID } from "node:crypto";
import { z } from "zod";
import { authenticateMobileRequest } from "@/lib/supabase/mobile";
import { readBoundedJson } from "@/lib/security/request";
import { loadStatementEvidence } from "@/lib/product/statement-evidence";
import { billReviewBaseline } from "@/lib/product/bill-review";
import { isTelecomCategory } from "../../../../../../../../apps/mobile/src/lib/bill-review";
import { evaluateBillTarget, parseBillTarget, sameOutcomeAccount, type OutcomeStatement, type BillTarget } from "../../../../../../../../apps/mobile/src/lib/bill-outcome";
import { historyDate } from "../../../../../../../../apps/mobile/src/lib/manual-history-insights";
import { moneyCents } from "../../../../../../../../apps/mobile/src/lib/statement-evidence";
export const dynamic = "force-dynamic";
const respond = (value: unknown, status = 200) => Response.json(value, { status, headers: { "Cache-Control": "private, no-store" } });
const date = z.string().refine(historyDate);
const amount = z.string().refine(v => moneyCents(v) !== null && moneyCents(v)! >= 0);
const schema = z.object({
  version: z.string(), title: z.string().trim().min(1).max(120), expectedAmount: amount,
  effectiveDate: date, cost: z.union([z.literal(""), amount]), notes: z.string().max(2000),
  state: z.enum(["planned", "implemented", "completed", "abandoned"]), evidenceBillId: z.string().uuid().nullable(),
  snoozedUntil: date.nullable(), agreementConfirmed: z.literal(true), confirmBaseline: z.boolean().optional(),
}).strict();
const literalPattern = (value: string) => value.trim().replace(/[\\%_]/g, "\\$&");
function statement(b: { id: string; custom_provider_name: string | null; account_number_masked: string | null; currency: string; amount: number | null; billing_period_start: string | null; billing_period_end: string | null; original_document_id: string | null }, category: string): OutcomeStatement {
  return { id: b.id, provider: b.custom_provider_name ?? "", account: b.account_number_masked ?? "", category, currency: b.currency, amount: b.amount, start: b.billing_period_start, end: b.billing_period_end, hasOriginal: Boolean(b.original_document_id) };
}
async function load(request: Request, id: string) {
  const auth = await authenticateMobileRequest(request);
  if (auth.error) return { response: respond({ error: auth.error.message }, auth.error.status) };
  if (!z.string().uuid().safeParse(id).success) return { response: respond({ error: "Choose a saved statement." }, 400) };
  const home = await auth.supabase.from("homes").select("id").eq("user_id", auth.user.id).order("created_at").limit(1).maybeSingle();
  if (home.error || !home.data) return { response: respond({ error: "Could not verify your household." }, 409) };
  const ctx = { supabase: auth.supabase, userId: auth.user.id, homeId: home.data.id };
  const loaded = await loadStatementEvidence(ctx, id);
  if ("error" in loaded) return { response: respond({ error: loaded.error }, loaded.status) };
  if (!isTelecomCategory(loaded.payload.category)) return { response: respond({ error: "Agreed-amount tracking currently supports saved internet and mobile statements. Utility usage savings need a different comparison." }, 409) };
  const baseline = statement(loaded.bill, loaded.payload.category);
  if (!baseline.provider.trim() || !baseline.account.trim()) return { response: respond({ error: "Add this statement’s provider and account nickname before tracking a change." }, 409) };
  const history = await auth.supabase.from(effectiveBillTable())
    .select("id,custom_provider_name,account_number_masked,currency,amount,billing_period_start,billing_period_end,original_document_id")
    .eq("user_id", ctx.userId).eq("home_id", ctx.homeId).eq("source", "manual").eq("status", "archived").eq("currency", baseline.currency)
    .eq("raw_data->>record_kind", "historical").eq("raw_data->>amount_basis", "period_charges").eq("raw_data->>category", baseline.category)
    .ilike("custom_provider_name", literalPattern(baseline.provider)).ilike("account_number_masked", literalPattern(baseline.account))
    .order("billing_period_end", { ascending: false }).order("id").limit(501);
  if (history.error) return { response: respond({ error: "Could not load the evidence. Your saved action is unchanged; try again." }, 503) };
  const records = history.data.map(b => statement(b, baseline.category)).filter(b => sameOutcomeAccount(baseline, b));
  const target = parseBillTarget(loaded.raw.bill_target);
  const hash = billReviewBaseline(loaded.bill);
  const loadedVersion = loaded.bill.updated_at;
  function payload(action: BillTarget | null, version = loadedVersion) {
    const evidence = records.find(b => b.id === action?.evidenceBillId) ?? null;
    let result = action ? evaluateBillTarget(action, baseline, hash, evidence, new Date().toLocaleDateString("en-CA", { timeZone: "America/Toronto" })) : null;
    if (result?.state === "awaiting_evidence" && action?.evidenceBillId && !evidence) result = {state:"awaiting_evidence", title:"Selected statement is no longer available", detail:"Choose another saved statement from this account, or upload the original again. No result is claimed from missing evidence.", differenceCents:null};
    const overlap = evidence && records.some(b => b.id !== evidence.id && historyDate(b.start) && historyDate(b.end) && historyDate(evidence.start) && historyDate(evidence.end) && b.start <= evidence.end && b.end >= evidence.start);
    if (result && ["matched", "different"].includes(result.state) && (records.length > 500 || overlap)) result = { state: "inconclusive", title: overlap ? "Check overlapping statements" : "History coverage is incomplete", detail: overlap ? "Another saved statement overlaps this evidence period. Check for a duplicate or revision before interpreting the result." : "The available history exceeds this check’s coverage. No result is verified.", differenceCents: null };
    return { version, baseline, evidence, candidateCount: records.filter(b => b.id !== id).length, baselineChanged: Boolean(action && action.baseline !== hash), target: action, result, candidates: records.filter(b => b.id !== id).slice(0, 100), coverageComplete: records.length <= 500 };
  }
  return { ctx, loaded, records, target, hash, baseline, payload };
}
export async function GET(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const state = await load(request, (await params).id);
  return "response" in state ? state.response : respond(state.payload(state.target));
}
export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const id = (await params).id, state = await load(request, id);
  if ("response" in state) return state.response;
  const parsed = schema.safeParse(await readBoundedJson(request, 12000).catch(() => null));
  if (!parsed.success) return respond({ error: "Check the agreed amount, effective date and action details." }, 400);
  const body = parsed.data;
  if (body.version !== state.loaded.bill.updated_at) return respond({ error: "This statement or action changed. Reload before saving; keep your edits until you review the saved version." }, 409);
  const stoppingExisting = body.state === "abandoned" && Boolean(state.target);
  if (!stoppingExisting && (!historyDate(state.baseline.end) || body.effectiveDate <= state.baseline.end)) return respond({ error: "Use a baseline statement that ends before the change takes effect." }, 400);
  if (body.evidenceBillId && !(stoppingExisting && body.evidenceBillId === state.target?.evidenceBillId) && !state.records.some(b => b.id === body.evidenceBillId && b.id !== id)) return respond({ error: "Choose a later statement from this account." }, 400);
  if (state.target && state.target.baseline !== state.hash && !body.confirmBaseline && body.state !== "abandoned") return respond({ error: "Review the corrected baseline and confirm it before updating this action." }, 409);
  const target: BillTarget = {
    id: state.target?.id ?? randomUUID(), title: body.title, expectedAmount: body.expectedAmount,
    effectiveDate: body.effectiveDate, cost: body.cost, notes: body.notes, state: body.state,
    evidenceBillId: body.evidenceBillId, baseline: body.confirmBaseline || !state.target ? state.hash : state.target.baseline,
    savedAt: new Date().toISOString(), snoozedUntil: body.snoozedUntil,
  };
  if (target.state === "completed" && !["matched", "different"].includes(state.payload(target).result?.state ?? "")) return respond({ error: "Choose a comparable statement before finishing this check, or stop tracking without claiming a result." }, 409);
  const raw = { ...state.loaded.raw, bill_target: target,
    ...(body.confirmBaseline && state.target?.baseline !== state.hash ? { bill_target_previous_baseline: { hash: state.target?.baseline, snapshot: state.loaded.raw.bill_target_baseline_snapshot } } : {}),
    ...(!state.target || body.confirmBaseline ? { bill_target_baseline_snapshot: state.baseline } : {}),
  };
  const saved = await state.ctx.supabase.from("bills").update({ raw_data: raw })
    .eq("id", id).eq("user_id", state.ctx.userId).eq("home_id", state.ctx.homeId).eq("updated_at", body.version)
    .eq("source", "manual").eq("status", "archived").select("updated_at").maybeSingle();
  if (saved.error) return respond({ error: "Could not confirm the save. Your edits remain; reload the saved action before retrying." }, 503);
  if (!saved.data) return respond({ error: "This action changed. Reload before saving again." }, 409);
  return respond(state.payload(target, saved.data.updated_at));
}
