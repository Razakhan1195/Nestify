import {unstable_cache} from "next/cache";
import type {Progress} from "./session";
export type Evidence={id:string;label:string;url:string;checkedAt:string;text:string;scope:"general"|"manual"};
const sources=[
 {id:"fridge",label:"Whirlpool: refrigerator troubleshooting",url:"https://www.whirlpool.ca/en_ca/blog/kitchen/refrigerator-troubleshooting.html",match:/fridge|refrigerator|freezer/i},
 {id:"dishwasher",label:"Whirlpool: dishwasher checks",url:"https://www.whirlpool.com/blog/kitchen/how-to-fix-a-dishwasher.html",match:/dishwash/i},
 {id:"washer",label:"Whirlpool: washing-machine checks",url:"https://www.whirlpool.com/blog/washers-and-dryers/how-to-fix-a-washing-machine.html",match:/washing machine|washer|laundry/i},
 {id:"tap",label:"Moen: faucet aerators",url:"https://solutions.moen.com/Article_Library/Faucet_Aerator_Cleaning",match:/faucet|tap|sink/i},
 {id:"network",label:"Rogers: internet connection checks",url:"https://www.rogers.com/support/internet/unable-to-access-the-internet-rogers-xfinity-gateway",match:/internet|wi.?fi|router|modem/i},
 {id:"thermostat",label:"Honeywell Home: heating checks",url:"https://www.honeywellhome.com/blogs/support/why-is-my-heating-not-working-no-heat",match:/thermostat|heating|furnace/i},
];
const hosts=new Set(sources.map(s=>new URL(s.url).hostname));
export function allowedGuideUrl(raw:string){try{const u=new URL(raw);return u.protocol==="https:"&&!u.username&&!u.password&&(!u.port||u.port==="443")&&hosts.has(u.hostname);}catch{return false;}}
export function articleText(html:string){
 const main=html.match(/<main\b[^>]*>([\s\S]*?)<\/main>/i)?.[1]??html;
 return main.replace(/<(script|style|nav|header|footer|svg)\b[^>]*>[\s\S]*?<\/\1>/gi," ").replace(/<[^>]+>/g," ").replace(/&nbsp;|&#160;/g," ").replace(/&amp;/g,"&").replace(/&quot;/g,'"').replace(/&#39;|&apos;/g,"'").replace(/&lt;/g,"<").replace(/&gt;/g,">").replace(/\s+/g," ").trim().slice(0,32000);
}
export async function readArticle(url:string):Promise<string>{
 let current=url;
 for(let redirects=0;redirects<3;redirects++){
  if(!allowedGuideUrl(current))throw Error("Unsupported source");
  const response=await fetch(current,{redirect:"manual",signal:AbortSignal.timeout(5000),headers:{"Accept":"text/html"}});
  if(response.status>=300&&response.status<400){current=new URL(response.headers.get("location")??"",current).href;continue;}
  if(!response.ok||!response.headers.get("content-type")?.includes("text/html"))throw Error("Source unavailable");
  if(Number(response.headers.get("content-length")??0)>1500000)throw Error("Source too large");
  const reader=response.body?.getReader();if(!reader)throw Error("Empty source");
  const chunks:Uint8Array[]=[];let size=0;
  try{while(true){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>1500000)throw Error("Source too large");chunks.push(value);}}finally{await reader.cancel().catch(()=>{});}
  const text=articleText(Buffer.concat(chunks).toString("utf8"));if(text.length<300)throw Error("Source unavailable");return text;
 }
 throw Error("Source redirect unavailable");
}
const cachedArticle=unstable_cache(async(url:string)=>({text:await readArticle(url),checkedAt:new Date().toISOString()}),["repair-official-evidence-v1"],{revalidate:86400});
export async function retrieveRepairEvidence(p:Progress):Promise<Evidence[]>{
 const symptom=[p.intake.description,p.intake.equipment,...p.attempts.slice(-8).map(a=>a.note)].join(" ");
 const selected=sources.filter(s=>s.match.test(symptom)).slice(0,2);
 const result=await Promise.allSettled(selected.map(async s=>{const article=await cachedArticle(s.url);if(!s.match.test(article.text))throw Error("Article content unavailable");return {...s,...article,scope:"general" as const};}));
 return result.flatMap(r=>r.status==="fulfilled"?[{id:r.value.id,label:r.value.label,url:r.value.url,text:r.value.text,checkedAt:r.value.checkedAt,scope:r.value.scope}]:[]);
}
