import { Feather } from "@expo/vector-icons";
import { Text, View } from "react-native";
import { Button } from "@/components/Button";
import { Surface } from "@/components/ui/Surface";
import type { ProviderConnectionItem } from "@/lib/provider-data";
import { colors, spacing, typography } from "@/theme/tokens";
export function TelecomImportProgress({progress,onLeave,onViewBill}:{progress:NonNullable<ProviderConnectionItem["importProgress"]>;onLeave:()=>void;onViewBill?:()=>void}) {
 const active=["preparing","queued","running","verification"].includes(progress.status);
 const needsPresence=active && (progress.status==="verification" || progress.authenticated !== true);
 const title=needsPresence ? (progress.status==="verification"?"Verify your sign-in":"Stay for sign-in") :progress.status==="verification"?"One quick verification":progress.status==="completed"?(progress.saved?"Your bill history is ready":"No bills in this date range"):progress.status==="partial"?(progress.saved?"Your saved bills are ready":"No bills found yet"):progress.status==="failed"?"Let’s finish your import":progress.saved>0?"Your latest bills are ready":"We’ll take it from here";
 return <Surface tone="subtle" style={{gap:spacing.md}}>
  <View style={{flexDirection:"row",gap:spacing.sm,alignItems:"center"}}><Feather name={progress.status==="completed"?"check-circle":"file-text"} size={22} color={colors.primary}/><Text style={[typography.section,{color:colors.foreground,flex:1}]}>{title}</Text></View>
  <Text style={[typography.body,{color:colors.mutedForeground}]}>{active&&progress.saved>0&&progress.status!=="verification"?"Adding the rest of your history. You can open your saved bills now.":progress.message}</Text>
  <View style={{gap:spacing.xs}}>
   <Text style={[typography.meta,{color:colors.foreground}]}>{progress.saved} statements saved · {progress.originals} original PDFs</Text>
   <Text style={[typography.caption,{color:colors.mutedForeground}]}>Requested history: {new Date(progress.sinceDate+"T12:00:00Z").toLocaleDateString("en-CA",{month:"short",day:"numeric",year:"numeric"})} to {new Date(progress.untilDate+"T12:00:00Z").toLocaleDateString("en-CA",{month:"short",day:"numeric",year:"numeric"})}</Text>
   {active&&progress.phase==="history"?<Text style={[typography.caption,{color:colors.mutedForeground}]}>Adding older bills in the background</Text>:null}
  </View>
  {active?<Text style={[typography.meta,{color:colors.mutedForeground}]}>{needsPresence ? "Keep the app open while your provider signs you in. Complete any verification below. We’ll tell you when it’s safe to leave." : "You’re signed in. You can close the app while we save your bills. With push notifications enabled, we’ll let you know when it finishes or if your provider asks for another check."}</Text>:null}
  {onViewBill?<Button label="View latest bill" onPress={onViewBill}/>:null}
  {!needsPresence ? <Button label={active?"Continue using Rezlee":"Go to Bills"} variant={onViewBill?"secondary":"primary"} onPress={onLeave}/> : null}
 </Surface>;
}
