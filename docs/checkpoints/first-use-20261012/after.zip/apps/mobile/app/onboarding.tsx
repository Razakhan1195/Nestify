import { Feather } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { useEffect, useRef, useState } from "react";
import {
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  Text,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

import { useAuth } from "@/auth/AuthProvider";
import { setupDrafts } from "@/lib/onboarding-draft";
import { shouldResumeSetup, type SetupDraft } from "@/lib/onboarding-draft-core";
import { AddressFields } from "@/components/AddressFields";
import { RezleeLoading } from "@/components/RezleeLoading";
import { validPostalCode } from "@/lib/canadian-address";
import { Button } from "@/components/Button";
import { TextField } from "@/components/TextField";
import { BillExamplePreview } from "@/components/BillExamplePreview";
import { StartingGoalOptions } from "@/components/HomeStartJourney";
import { startingContent, type StartingGoal } from "@/lib/home-start";
import { saveStartingGoal } from "@/lib/home-start-preference";
import { ApiError } from "@/lib/api";
import {
  createHomeProfile,
  fetchOnboarding,
  type HomeProfileInput,
  type OnboardingPayload,
} from "@/lib/onboarding-data";
import { colors, layout, radii, spacing, typography } from "@/theme/tokens";

type Step = 1 | 2;
function Progress({ step }: { step: Step }) {
  return (
    <View style={{ flexDirection: "row", gap: spacing.sm }}>
      {[1, 2].map((value) => (
        <View
          key={value}
          style={{
            flex: 1,
            height: 4,
            borderRadius: radii.full,
            backgroundColor: value <= step ? colors.primary : colors.muted,
          }}
        />
      ))}
    </View>
  );
}

function OptionSelector({
  label,
  options,
  value,
  onChange,
  disabled = false,
}: {
  disabled?: boolean;
  label: string;
  options: string[];
  value: string;
  onChange: (value: string) => void;
}) {
  return (
    <View style={{ gap: spacing.sm }}>
      <Text style={{ fontSize: 13, fontWeight: "600", color: colors.mutedForeground }}>
        {label}
      </Text>
      <View style={{ flexDirection: "row", flexWrap: "wrap", gap: spacing.sm }}>
        {options.map((option) => {
          const active = value === option;
          return (
            <Pressable
              key={option}
              accessibilityRole="button"
              accessibilityState={{ selected: active, disabled }}
              disabled={disabled}
              onPress={() => onChange(option)}
              style={({ pressed }) => ({
                minHeight: layout.touchMin,
                justifyContent: "center",
                paddingHorizontal: spacing.md,
                borderRadius: radii.full,
                backgroundColor: active ? colors.primary : colors.secondary,
                opacity: pressed ? 0.86 : 1,
              })}
            >
              <Text style={{ fontSize: 13, fontWeight: "600", color: active ? colors.primaryForeground : colors.secondaryForeground }}>
                {option === "Shared home" ? "Shared with roommates" : option}
              </Text>
            </Pressable>
          );
        })}
      </View>
    </View>
  );
}
export default function OnboardingScreen() {
  const router = useRouter();
  const { session } = useAuth();
  const userId = session?.user.id;
  const active = useRef(true);
  const draftRevision = useRef(0);
  const [draftNotice, setDraftNotice] = useState<string | null>(null);
  const [restored, setRestored] = useState(false);
  const finishLock = useRef(false);
  const saveLock = useRef(false);
  const [addressResolving, setAddressResolving] = useState(false);
  const [moreDetails, setMoreDetails] = useState(false);
  const [attempt, setAttempt] = useState(0);
  const [payload, setPayload] = useState<OnboardingPayload | null>(null);
  const [step, setStep] = useState<Step>(1);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [showExample, setShowExample] = useState(false);
  const [selectedGoal, setSelectedGoal] = useState<StartingGoal>("bills");
  const [form, setForm] = useState<HomeProfileInput>({
    nickname: "Home",
    street_address: "",
    city: "",
    province: "",
    postal_code: "",
    home_type: "",
    ownership_type: "",
    approximate_year_built: "",
  });

  useEffect(() => { active.current = true; return () => { active.current = false; }; }, []);

  useEffect(() => {
    if (!userId) return;
    let active = true;
    Promise.all([fetchOnboarding(), setupDrafts.read(userId)])
      .then(([data, draft]) => {
        if (!active) return;
        if (data.home) {
          if (shouldResumeSetup(draft, data.home.id, data.accessRole)) {
            setStep(2);
            setSelectedGoal(draft!.goal);
            setForm(draft!.form);
            setRestored(true);
          } else {
            void setupDrafts.clear(userId).catch(() => {});
            router.replace("/(tabs)/home");
            return;
          }
        } else if (draft) {
          setForm(draft.form);
          setSelectedGoal(draft.goal);
          setMoreDetails(Boolean(draft.form.approximate_year_built || (draft.form.nickname && draft.form.nickname !== "Home")));
          setRestored(true);
        }
        setPayload(data);
      })
      .catch((loadError) => {
        if (!active) return;
        setError(
          loadError instanceof ApiError
            ? loadError.message
            : "We could not start setup. Please try again.",
        );
      })
      .finally(() => {
        if (active) setIsLoading(false);
      });

    return () => {
      active = false;
    };
  }, [router, attempt, userId]);

  function draftFor(nextForm: HomeProfileInput, goal = selectedGoal, phase: SetupDraft["phase"] = step === 2 ? "choose" : "form"): SetupDraft {
    return { version: 1, updatedAt: Date.now(), form: nextForm, goal, phase, ...(payload?.home ? { homeId: payload.home.id } : {}) };
  }
  function persistDraft(draft: SetupDraft) {
    if (!userId) return;
    const revision = ++draftRevision.current;
    setDraftNotice("Saving progress…");
    void setupDrafts.write(userId, draft).then(() => {
      if (active.current && revision === draftRevision.current) setDraftNotice("Progress saved on this device.");
    }).catch(() => {
      if (active.current && revision === draftRevision.current) setDraftNotice("Progress couldn’t be saved on this device. Keep this screen open and try again.");
    });
  }
  function updateForm(change: Partial<HomeProfileInput>) {
    const next = { ...form, ...change };
    setForm(next); persistDraft(draftFor(next));
  }
  function chooseGoal(goal: StartingGoal) {
    setSelectedGoal(goal); persistDraft(draftFor(form, goal));
  }

  const canSavePlace = Boolean(
    form.city.trim() &&
      form.province.trim() &&
      validPostalCode(form.postal_code) &&
      form.home_type &&
      form.ownership_type,
  );

  async function savePlace() {
    if (!userId || !canSavePlace || addressResolving || saveLock.current) return;
    saveLock.current = true;
    setError(null);
    setIsSaving(true);
    try {
      await setupDrafts.write(userId, draftFor(form, selectedGoal, "saving"));
      const next = await createHomeProfile({ ...form, nickname: form.nickname.trim() || "Home" });
      setPayload(next);
      setStep(2);
      if (next.home) {
        try { await setupDrafts.write(userId, { ...draftFor(form, selectedGoal, "choose"), homeId: next.home.id }); }
        catch { setDraftNotice("Your place is saved. Finish below to choose your next step."); }
      }
    } catch (saveError) {
      setError(
        saveError instanceof ApiError
          ? saveError.message
          : "We could not save your place. Please try again.",
      );
    } finally {
      saveLock.current = false;
      setIsSaving(false);
    }
  }
  async function finish(startTask: boolean) {
    if (!userId || !payload?.home || finishLock.current) return;
    finishLock.current = true;
    setIsSaving(true); setError(null);
    try {
      await saveStartingGoal(payload.home.id, selectedGoal);
      await setupDrafts.clear(userId);
      router.replace({ pathname: "/(tabs)/home", params: { begin: startTask ? selectedGoal : "" } });
    } catch {
      setError("We couldn’t finish setup. Please try again.");
    } finally { finishLock.current = false; setIsSaving(false); }
  }
  if (isLoading) {
    return (
      <SafeAreaView style={{ flex: 1, backgroundColor: colors.background, alignItems: "center", justifyContent: "center" }}>
        <RezleeLoading />
      </SafeAreaView>
    );
  }

  if (!payload) {
    return (
      <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
        <View style={{ flex: 1, justifyContent: "center", paddingHorizontal: layout.screenHorizontal, gap: spacing.md }}>
          <Feather name="alert-circle" size={28} color={colors.criticalForeground} />
          <Text style={[typography.title, { color: colors.foreground }]}>Setup could not load</Text>
          <Text style={[typography.body, { color: colors.mutedForeground }]}>
            {error ?? "Please return to sign in and try again."}
          </Text>
          <Button label="Try again" onPress={() => { setIsLoading(true); setError(null); setAttempt(value => value + 1); }} />
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }} edges={["top"]}>
      <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} style={{ flex: 1 }}>
        <ScrollView
          keyboardShouldPersistTaps="handled"
          keyboardDismissMode="on-drag"
          contentInsetAdjustmentBehavior="never"
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{
            paddingHorizontal: layout.screenHorizontal,
            paddingTop: spacing.lg,
            paddingBottom: spacing["4xl"],
            gap: spacing.xl,
          }}
        >
          <Progress step={step} />
          {restored ? <Text accessibilityLiveRegion="polite" style={[typography.meta, { color: colors.mutedForeground }]}>Continue where you left off.</Text> : null}
          {draftNotice ? <Text accessibilityLiveRegion="polite" style={[typography.meta, { color: colors.mutedForeground }]}>{draftNotice}</Text> : null}

          {step === 1 ? (
            <View style={{ gap: spacing.xl }}>
              <View style={{ gap: spacing.xs }}>
                <Text style={[typography.label, { color: colors.mutedForeground }]}>Step 1 of 2</Text>
                <Text style={[typography.heading, { color: colors.foreground }]}>Set up your place</Text>
                <Text style={[typography.body, { color: colors.mutedForeground }]}>
                  Your location helps keep home guidance relevant. A street address is optional. You can edit these details later.
                </Text>
              </View>

              <View style={{ gap: spacing.md }}>
                <AddressFields onResolvingChange={setAddressResolving} value={form} disabled={isSaving} searchEnabled={payload.addressSearchAvailable === true} onChange={address => updateForm(address)} />
                {form.postal_code.length >= 6 && !validPostalCode(form.postal_code) ? <Text accessibilityRole="alert" style={{ color: colors.criticalForeground }}>Enter a Canadian postal code, such as A1A 1A1.</Text> : null}
                <Pressable accessibilityRole="button" accessibilityState={{ expanded: moreDetails }} disabled={isSaving} onPress={() => setMoreDetails(value => !value)}
                  style={{ minHeight: 44, flexDirection: "row", alignItems: "center", gap: spacing.sm }}>
                  <Text style={[typography.body, { color: colors.primary }]}>More details (optional)</Text>
                  <Feather name={moreDetails ? "chevron-up" : "chevron-down"} size={18} color={colors.primary} />
                </Pressable>
                {moreDetails ? <View style={{ gap: spacing.md }}>
                  <TextField label="Home nickname" maxLength={80} editable={!isSaving} value={form.nickname} onChangeText={nickname => updateForm({ nickname })} />
                  <TextField label="Approximate year built" maxLength={4} editable={!isSaving} keyboardType="number-pad" placeholder="2018" value={form.approximate_year_built} onChangeText={approximate_year_built => updateForm({ approximate_year_built })} />
                </View> : null}
              </View>

              <OptionSelector
                disabled={isSaving}
                label="Home type"
                options={payload.homeTypeOptions}
                value={form.home_type}
                onChange={home_type => updateForm({ home_type })}
              />
              <OptionSelector
                disabled={isSaving}
                label="Living situation"
                options={payload.ownershipTypeOptions}
                value={form.ownership_type}
                onChange={ownership_type => updateForm({ ownership_type })}
              />

              {error ? <Text style={{ fontSize: 13, color: colors.criticalForeground }}>{error}</Text> : null}
              <Button label="Continue" loading={isSaving} disabled={!canSavePlace || addressResolving} onPress={savePlace} />
            </View>
          ) : null}
          {step === 2 ? <View style={{ gap: spacing.xl }}>
            <View style={{ gap: spacing.sm }}>
              <Text style={[typography.label, { color: colors.mutedForeground }]}>Your place is ready</Text>
              <Text accessibilityRole="header" style={[typography.heading, { color: colors.foreground }]}>What would help today?</Text>
              <Text style={[typography.body, { color: colors.mutedForeground }]}>Start with one useful thing. Rezlee brings saved changes and upcoming dates into view on Home. You can add the rest later.</Text>
            </View>
            <StartingGoalOptions selected={selectedGoal} onSelect={chooseGoal} disabled={isSaving} />
            {selectedGoal === "bills" ? <View style={{ gap: spacing.sm }}>
              <Text style={[typography.meta, { color: colors.mutedForeground }]}>Next, choose how to add a bill: upload a statement, enter details or connect your provider. No connection is required.</Text>
              <Pressable accessibilityRole="button" accessibilityState={{ expanded: showExample }} onPress={() => setShowExample(value => !value)} style={{ minHeight: 44, justifyContent: "center" }}>
                <Text style={[typography.meta, { color: colors.primary, fontWeight: "600" }]}>{showExample ? "Hide example" : "See what you can learn"}</Text>
              </Pressable>
              {showExample ? <><BillExamplePreview /><Text style={[typography.caption, { color: colors.mutedForeground }]}>Fictional example using three completed statements. Your own results depend on the bills you add.</Text></> : null}
            </View> : null}
            {error ? <Text accessibilityRole="alert" style={[typography.body, { color: colors.criticalForeground }]}>{error}</Text> : null}
            <Button label={startingContent[selectedGoal].action} loading={isSaving} onPress={() => void finish(true)} />
            <Pressable accessibilityRole="button" disabled={isSaving} onPress={() => void finish(false)} style={{ minHeight: layout.touchMin, justifyContent: "center", alignItems: "center" }}>
              <Text style={[typography.body, { color: colors.primary }]}>Explore my Home first</Text>
            </Pressable>
          </View> : null}
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}
