import { CareSetupTiles } from "@/components/CareSetupTiles";
import { Feather } from "@expo/vector-icons";
import { Redirect, useFocusEffect, useLocalSearchParams, useRouter } from "expo-router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { ActivityIndicator, FlatList, Pressable, RefreshControl, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

import { acknowledgeCareSave } from "@/lib/care-save";
import { CollectionToolbar, CollectionAddSheet } from "@/components/CollectionUI";
import { Button } from "@/components/Button";
import { ActionCard } from "@/components/ActionCard";
import { QuietAction } from "@/components/Brief";
import { FilterChips } from "@/components/FilterChips";
import { Surface } from "@/components/ui/Surface";
import { ApiError } from "@/lib/api";
import {
  careFilters,
  completeCareTask,
  fetchCare,
  formatCareDate,
  formatCareRecurrence,
  type CareFilter,
  type CarePayload,
  type CareTask,
} from "@/lib/care-data";
import { colors, layout, radii, spacing, typography } from "@/theme/tokens";

const statusMeta = {
  overdue: { label: "Overdue", bg: colors.criticalBg, fg: colors.criticalForeground },
  due_soon: { label: "Due soon", bg: colors.warningBg, fg: colors.warningForeground },
  upcoming: { label: "Upcoming", bg: colors.infoBg, fg: colors.infoForeground },
  completed: { label: "Done", bg: colors.successBg, fg: colors.successForeground },
} as const;
function CareRow({ task, onComplete, onOpen, busy, canComplete }: { canComplete: boolean; busy: boolean; task: CareTask; onComplete: (task: CareTask) => void; onOpen: (task: CareTask) => void }) {
  const meta = statusMeta[task.displayStatus];
  const done = task.displayStatus === "completed";
  return (
    <Pressable
      accessibilityRole="button" accessibilityLabel={`${task.title}. View task`}
      onPress={() => onOpen(task)}
      style={({ pressed }) => ({
        flexDirection: "row",
        alignItems: "center",
        gap: spacing.md,
        paddingVertical: spacing.md,
        opacity: pressed ? 0.76 : 1,
      })}
    >
      <Pressable
        disabled={done || busy || !canComplete}
        accessibilityRole="button"
        accessibilityLabel={done ? `${task.title} completed` : canComplete ? `Mark ${task.title} complete` : `${task.title} is assigned to another household member`}
        accessibilityState={{disabled:done || busy || !canComplete}}
        onPress={(event) => {
          event.stopPropagation();
          if (!done && !busy && canComplete) onComplete(task);
        }}
        style={{ width: 44, height: 44, borderRadius: 15, backgroundColor: done ? colors.successBg : colors.surfaceRaised, borderWidth: 1, borderColor: done ? colors.successBg : colors.border, alignItems: "center", justifyContent: "center" }}
      >
        <Feather name={!done && !canComplete ? "user" : "check"} size={18} color={done ? colors.successForeground : colors.borderStrong} />
      </Pressable>
      <View style={{ flex: 1, gap: 4 }}>
        <Text style={{ fontSize: 15, fontWeight: "700", color: colors.foreground, textDecorationLine: done ? "line-through" : "none" }} numberOfLines={1}>{task.title}</Text>
        <Text style={[typography.caption, { color: colors.mutedForeground }]} numberOfLines={1}>{[formatCareDate(task.due_date), formatCareRecurrence(task.recurrence), task.category].filter(Boolean).join(" · ")}</Text>
      </View>
      <View style={{ alignItems: "flex-end", gap: 6 }}>
        <View style={{ paddingHorizontal: 8, paddingVertical: 3, borderRadius: radii.full, backgroundColor: meta.bg }}>
          <Text style={{ fontSize: 10, fontWeight: "700", color: meta.fg }}>{meta.label}</Text>
        </View>
        {task.assigneeName ? (
          <View style={{ flexDirection: "row", alignItems: "center", gap: 4, maxWidth: 110 }}>
            <Feather name={task.rotating ? "repeat" : "user"} size={11} color={colors.primary} />
            <Text style={{ fontSize: 11, fontWeight: "600", color: colors.primary }} numberOfLines={1}>{task.assigneeName}</Text>
          </View>
        ) : null}
      </View>
    </Pressable>
  );
}
export default function CareScreen() {
  const router = useRouter();
  const [adding,setAdding]=useState(false);
  const params = useLocalSearchParams<{ routineAdded?: string; planAdded?: string; reminderAdded?: string; savedRequestId?: string }>();
  useEffect(() => {
    if (params.savedRequestId && (params.routineAdded || params.planAdded || params.reminderAdded)) void acknowledgeCareSave(params.reminderAdded ? "reminder" : params.routineAdded ? "routine" : "plan", params.savedRequestId);
  }, [params.savedRequestId, params.routineAdded, params.planAdded, params.reminderAdded]);
  const [payload, setPayload] = useState<CarePayload | null>(null);
  const [filter, setFilter] = useState<CareFilter>("all");
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const completing = useRef(false);
  const loadVersion = useRef(0);
  const [confirmation, setConfirmation] = useState<string | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);

  const load = useCallback(async (refresh = false) => {
    const version = ++loadVersion.current;
    if (refresh) setIsRefreshing(true);
    setError(null);
    try {
      const next = await fetchCare();
      if (version === loadVersion.current) setPayload(next);
    } catch (loadError) {
      if (version === loadVersion.current) setError(loadError instanceof ApiError ? loadError.message : "We could not load Care. Please try again.");
    } finally {
      if (version === loadVersion.current) { setIsLoading(false); setIsRefreshing(false); }
    }
  }, []);

  useFocusEffect(useCallback(() => { void load(); return () => { loadVersion.current++; setIsRefreshing(false); }; }, [load]));

  const tasks = useMemo(() => payload && !payload.needsOnboarding ? payload.tasks : [], [payload]);
  const visibleTasks = useMemo(
    () => tasks.filter((task) => filter === "all" || task.displayStatus === filter),
    [tasks, filter],
  );
  const accessRole = payload && !payload.needsOnboarding ? payload.accessRole ?? "owner" : "owner";
  const isOwner = accessRole === "owner";
  const openCount = tasks.filter((task) => task.displayStatus !== "completed").length;
  const dueSoonCount = tasks.filter((task) => task.displayStatus === "overdue" || task.displayStatus === "due_soon").length;

  async function handleComplete(task: CareTask) {
    if (completing.current || !(task.canComplete ?? isOwner)) return;
    completing.current = true;
    setBusyId(task.id);
    try {
      const result = await completeCareTask(task.id);
      setConfirmation(result.alreadyCompleted ? `${task.title} was already completed.` : `${task.title} completed. ${result.nextDate ? `Next occurrence: ${formatCareDate(result.nextDate)}.` : "Saved in Done. No repeat scheduled."}`);
      await load();
    } catch (completeError) {
      setError(completeError instanceof ApiError ? completeError.message : "Could not complete this task.");
    } finally {
      completing.current = false;
      setBusyId(null);
    }
  }
  if (isLoading) {
    return (
      <SafeAreaView edges={["left", "right"]} style={{ flex: 1, backgroundColor: colors.canvas, alignItems: "center", justifyContent: "center" }}>
        <ActivityIndicator color={colors.primary} />
      </SafeAreaView>
    );
  }

  if (error && !payload) {
    return (
      <SafeAreaView edges={["left", "right"]} style={{ flex: 1, backgroundColor: colors.canvas }}>
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center", gap: spacing.md, paddingHorizontal: spacing["2xl"] }}>
          <Feather name="alert-circle" size={28} color={colors.criticalForeground} />
          <Text style={[typography.body, { color: colors.foreground, textAlign: "center" }]}>{error}</Text>
          <QuietAction label="Try again" onPress={()=>void load()}/>
        </View>
      </SafeAreaView>
    );
  }

  if (!payload || payload.needsOnboarding) return <Redirect href="/onboarding" />;

  return (
    <SafeAreaView edges={["left", "right"]} style={{ flex: 1, backgroundColor: colors.canvas }}>
      <FlatList contentInsetAdjustmentBehavior="never" automaticallyAdjustContentInsets={false}
        data={visibleTasks}
        keyExtractor={(task) => task.id}
        contentContainerStyle={{ paddingHorizontal: layout.screenHorizontal, paddingTop: layout.screenTop, paddingBottom: spacing["4xl"] }}
        refreshControl={<RefreshControl refreshing={isRefreshing} onRefresh={() => load(true)} tintColor={colors.primary} />}
        ItemSeparatorComponent={() => <View style={{ height: 1, backgroundColor: colors.border }} />}
        ListHeaderComponent={
          <View style={{ gap: spacing.xl, marginBottom: spacing.lg }}>
            {params.reminderAdded ? <View accessibilityLiveRegion="polite" style={{padding:16,borderRadius:14,backgroundColor:colors.successBg}}><Text style={[typography.body,{color:colors.successForeground}]}>Reminder saved. Review its date below.</Text><QuietAction label="Dismiss" onPress={()=>router.setParams({reminderAdded:undefined})}/></View>:null}
            {params.planAdded ? <View style={{ padding: 16, borderRadius: 14, backgroundColor: colors.successBg }}><Text style={[typography.body, { color: colors.successForeground }]}>{params.planAdded} maintenance tasks added. Review their dates below.</Text><QuietAction label="Dismiss" onPress={() => router.setParams({ planAdded: undefined })} /></View> : null}
            {confirmation ? <View accessibilityLiveRegion="polite" style={{ padding: 16, borderRadius: 14, backgroundColor: colors.successBg }}><Text style={[typography.body, { color: colors.successForeground }]}>{confirmation}</Text><QuietAction label="Dismiss" onPress={() => setConfirmation(null)} /></View> : null}
            {params.routineAdded ? (
              <Surface tone="accent" style={{ flexDirection: "row", alignItems: "center", gap: spacing.md }}>
                <View style={{ width: 44, height: 44, borderRadius: 15, backgroundColor: colors.successBg, alignItems: "center", justifyContent: "center" }}>
                  <Feather name="check-circle" size={19} color={colors.successForeground} />
                </View>
                <View style={{ flex: 1, gap: 2 }}>
                  <Text style={{ fontSize: 14, fontWeight: "700", color: colors.foreground }}>Cleaning routine is active</Text>
                  <Text style={[typography.caption, { color: colors.mutedForeground }]}>{params.routineAdded} recurring {params.routineAdded === "1" ? "task was" : "tasks were"} added below. Complete a task and Rezlee schedules its next occurrence automatically.</Text><QuietAction label="Dismiss" onPress={() => router.setParams({ routineAdded: undefined })} />
                </View>
              </Surface>
            ) : null}

            <CollectionToolbar title="Care" description={openCount?`${openCount} open task${openCount===1?"":"s"}${dueSoonCount?` · ${dueSoonCount} due soon or overdue`:""}`:"Tasks and reminders for your home."} label="Add to Care" onAdd={isOwner?()=>setAdding(true):undefined}/>
            {isOwner ? <QuietAction label="Manage cleaning routines" onPress={() => router.push("/care/routines")} /> : null}
            <ActionCard title="Help me fix this" detail="Try a safe fix, save what worked, or get ready to ask for help." icon="tool" onPress={()=>router.push("/repairs")}/>
             {isOwner?<QuietAction label="Before I spend · review a quote" onPress={()=>router.push("/quotes")}/>:null}
            {!isOwner ? (
              <Surface tone="accent" style={{ flexDirection: "row", alignItems: "center", gap: spacing.lg }}>
                <View style={{ width: 46, height: 46, borderRadius: 16, backgroundColor: colors.surfaceRaised, alignItems: "center", justifyContent: "center" }}>
                  <Feather name="users" size={20} color={colors.primary} />
                </View>
                <View style={{ flex: 1, gap: 3 }}>
                  <Text style={{ fontSize: 15, fontWeight: "700", color: colors.foreground }}>Shared responsibilities</Text>
                  <Text style={[typography.caption, { color: colors.mutedForeground, lineHeight: 17 }]}>You can complete tasks assigned to you or left unassigned. The household owner manages routines and assignments.</Text>
                </View>
              </Surface>
            ) : null}

            {tasks.length ? <FilterChips options={careFilters} selected={filter} onSelect={setFilter} /> : null}
            {error ? <Text style={{ fontSize: 13, color: colors.criticalForeground }}>{error}</Text> : null}
          </View>
        }
        ListFooterComponent={isOwner ? <CareSetupTiles adoption={payload.adoption} onStart={kind=>router.push(kind==="reminder"?"/care/add":kind==="cleaning"?"/care/routine":"/care/plan")}/> : null}
        ListEmptyComponent={
          isOwner && !tasks.length && payload.adoption && Object.values(payload.adoption).some(value=>value===false) ? null : <View style={{ alignItems: "center", gap: spacing.lg, paddingVertical: spacing["3xl"] }}>

            <View style={{ alignItems: "center", gap: spacing.sm, maxWidth: 300 }}>
              <Text style={[typography.title, { color: colors.foreground, textAlign: "center" }]}>{filter === "all" ? "No care tasks yet" : "Nothing in this view"}</Text>
              <Text style={[typography.body, { color: colors.mutedForeground, textAlign: "center" }]}>
                {filter === "all" ? (isOwner ? "Set a reminder, create a cleaning routine or plan seasonal maintenance." : "Tasks will appear here when your household owner adds them.") : "Try another filter to find saved tasks."}
              </Text>
            </View>
            {filter === "all" && isOwner ? (
              <Button label="Add to Care" onPress={() => setAdding(true)}/>
            ) : null}
          </View>
        }
        renderItem={({ item }) => (
          <View style={{ opacity: busyId === item.id ? 0.5 : 1 }}>
            <CareRow canComplete={item.canComplete ?? isOwner} busy={busyId !== null} task={item} onComplete={handleComplete} onOpen={(task) => router.push(`/care/${task.id}`)} />
          </View>
        )}
      />
      <CollectionAddSheet title="Add to Care" visible={adding} onClose={()=>setAdding(false)} choices={[
       {key:"task",title:"Task or reminder",detail:"Set a date and repeat if needed.",icon:"calendar",onPress:()=>router.push("/care/add")},
       {key:"routine",title:"Cleaning routine",detail:"Choose recurring tasks for your household.",icon:"repeat",onPress:()=>router.push("/care/routine")},
       {key:"plan",title:"Maintenance plan",detail:"Review suggested tasks before adding them.",icon:"tool",onPress:()=>router.push("/care/plan")},
      ]}/>
    </SafeAreaView>
  );
}