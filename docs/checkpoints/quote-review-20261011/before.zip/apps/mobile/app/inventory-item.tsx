import { prepareAttachment } from "@/lib/prepare-attachment";
import { applianceSuggestions } from "@/lib/capture-review";
import { safeBack } from "@/lib/navigation";
import { DateField } from "@/components/DateField";
import { BarcodeLookup, type ProductSuggestion } from "@/components/BarcodeLookup";
import { useCallback, useEffect, useRef, useState } from "react";
import { useLocalSearchParams, useRouter, useNavigation, useFocusEffect } from "expo-router";
import { usePreventRemove } from "expo-router/react-navigation";
import * as ImagePicker from "expo-image-picker";
import { ActivityIndicator, Alert, KeyboardAvoidingView, Platform, Pressable, ScrollView, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { ScreenNavigation } from "@/components/ScreenNavigation";
import { TextField } from "@/components/TextField";
import { Button } from "@/components/Button";
import { apiGet, apiPost, apiFormPost, apiDelete, ApiError } from "@/lib/api";
import { PHOTO_TYPES, uploadMimeType, uploadValidationError } from "@/lib/upload-validation";
import { colors, spacing, typography } from "@/theme/tokens";
const empty = { name: "", brand: "", model_number: "", serial_number: "", room_or_area: "", category: "", product_barcode: "", warranty_expires_on: "" };
type Fields = typeof empty;
export default function InventoryItemScreen() {
  const params = useLocalSearchParams<{ id?: string }>();
  const id = typeof params.id === "string" ? params.id : undefined;
  const router = useRouter();
  const navigation = useNavigation();
  const [fields, setFields] = useState<Fields>(empty);
  const scanInFlight = useRef(false);
  const [barcodeOpen, setBarcodeOpen] = useState(false);
  const [showCapture, setShowCapture] = useState(!id);
  const saveInFlight = useRef(false);
  const [showDetails, setShowDetails] = useState(Boolean(id));
  const [showOptional, setShowOptional] = useState(Boolean(id));
  const [dirty, setDirty] = useState(false);
  const [loading, setLoading] = useState(Boolean(id));
  const [loadFailed, setLoadFailed] = useState(false);
  const [busy, setBusy] = useState<"scan" | "save" | "delete" | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [deleted, setDeleted] = useState(false);
  const [savedId, setSavedId] = useState<string | null>(null);
  usePreventRemove((dirty || Boolean(busy)) && !savedId && !deleted, ({ data }) => {
    if (busy) { Alert.alert("Please wait", busy === "delete" ? "Your item is being deleted." : busy === "save" ? "Your item is being saved." : "Your label is being read."); return; }
    Alert.alert("Discard unsaved changes?", "Your changes have not been saved.", [
      { text: "Keep editing", style: "cancel" },
      { text: "Discard", style: "destructive", onPress: () => navigation.dispatch(data.action) },
    ]);
  });
  const load = useCallback(async () => {
    if (!id) return;
    try {
      const result = await apiGet<{ item: Partial<Fields> }>("/api/mobile/v1/inventory?id=" + encodeURIComponent(id));
      setLoadFailed(false); setError(null);
      setFields(Object.fromEntries(Object.keys(empty).map((key) => [key, result.item[key as keyof Fields] ?? ""])) as Fields);
    } catch (e) { setLoadFailed(true); setError(e instanceof ApiError ? e.message : "Could not load your item."); }
    finally { setLoading(false); }
  }, [id]);
  useFocusEffect(useCallback(() => { if (!dirty) void load(); }, [load, dirty]));
  useEffect(() => {
    if (deleted) safeBack(router, "/(tabs)/vault");
    else if (savedId) router.replace({ pathname: "/recalls", params: { itemId: savedId, saved: "1" } });
  }, [savedId, deleted, router]);
  async function scan(camera: boolean) {
    if (scanInFlight.current) return;
    scanInFlight.current = true;
    setBusy("scan"); setError(null); setNotice(null);
    try {
      if (camera) {
        const permission = await ImagePicker.requestCameraPermissionsAsync();
        if (!permission.granted) { setError("Camera access is off. Choose a saved photo or enter details manually."); return; }
      }
      const options: ImagePicker.ImagePickerOptions = { mediaTypes: ["images"], quality: 0.8 };
      const result = camera ? await ImagePicker.launchCameraAsync(options) : await ImagePicker.launchImageLibraryAsync(options);
      if (result.canceled || !result.assets[0]) return;
      const asset = result.assets[0];
      const prepared = await prepareAttachment({ uri: asset.uri, name: asset.fileName ?? "product-label.jpg", type: uploadMimeType(asset.fileName ?? "product-label.jpg", asset.mimeType), size: asset.fileSize, width: asset.width, height: asset.height });
      const type = prepared.type;
      const invalid = uploadValidationError(prepared.size, type, PHOTO_TYPES);
      if (invalid) { setError(invalid); return; }
      const form = new FormData();
      form.append("kind", "appliance");
      form.append("file", { uri: prepared.uri, name: prepared.name, type } as unknown as Blob);
      const extracted = await apiFormPost<{ data: Record<string, unknown> }>("/api/mobile/v1/ai/scan", form, { timeoutMs: 55000 });
      const values = applianceSuggestions(extracted.data);
      setShowDetails(true);
      if (!Object.values(values).some(Boolean)) { setError("The label wasn’t readable. Try a closer photo of the model label, or add just an item name for now."); return; }
      const conflict = (["brand", "model_number", "serial_number"] as const).some(key => fields[key] && values[key] && fields[key].toLowerCase() !== values[key].toLowerCase());
      const apply = (replace: boolean) => {
        setFields(current => replace ? values : Object.fromEntries(Object.keys(empty).map(key => [key, current[key as keyof Fields] || values[key as keyof Fields]])) as Fields);
        setDirty(true); setShowCapture(false);
        setNotice("Read from your photo. Check the exact model and any dates before confirming. Nothing is saved yet.");
      };
      if (conflict) Alert.alert("This label has different details", "Keep your current details, or replace them with this label’s suggestions. Replacement clears any old details the new label does not provide.", [
        { text: "Keep current details", style: "cancel" },
        { text: "Use this label", onPress: () => apply(true) },
      ]);
      else apply(false);
    } catch (e) { setError(e instanceof ApiError ? e.message : "Could not read that label. Try another photo or enter details manually."); }
    finally { scanInFlight.current = false; setBusy(null); }
  }
  function applyProduct(product: ProductSuggestion) {
    const apply = () => {
      setFields(current => ({ ...current, name: product.name, brand: product.brand, model_number: product.model_number, product_barcode: product.product_barcode }));
      setDirty(true); setBarcodeOpen(false); setShowDetails(true); setShowCapture(false);
      setNotice("Product details added from UPCitemdb. Confirm the brand and exact model before saving. Your serial number, room and other details were kept.");
    };
    if (["name", "brand", "model_number", "product_barcode"].some(key => fields[key as keyof Fields] && fields[key as keyof Fields] !== product[key as keyof ProductSuggestion])) {
      Alert.alert("Replace product details?", "The selected product differs from the name, brand, model or barcode you entered. Replace those details with this suggestion? Brand or model fields not supplied by the directory will be cleared so an old value is not attached to a different product.", [{text:"Keep editing",style:"cancel"},{text:"Use suggestion",onPress:apply}]);
    } else apply();
  }
  async function remove() {
    if (!id || busy) return;
    setBusy("delete"); setError(null);
    try {
      await apiDelete("/api/mobile/v1/inventory?id=" + encodeURIComponent(id));
      setDeleted(true); Alert.alert("Home item deleted", "The item and its saved warranty details have been removed. Separately saved records are kept.");
    } catch (e) { setError(e instanceof ApiError ? e.message : "Could not confirm deletion. Please try again."); }
    finally { setBusy(null); }
  }
  function confirmDelete() {
    if (busy) return;
    Alert.alert("Delete this home item?", "This removes the item and its warranty details. Separately saved receipts and records are kept. Unsaved changes will be discarded.", [
      { text: "Keep item", style: "cancel" },
      { text: "Delete item", style: "destructive", onPress: () => void remove() },
    ]);
  }
  async function save() {
    if (saveInFlight.current || busy || !fields.name.trim()) return;
    saveInFlight.current = true;
    setBusy("save"); setError(null);
    try {
      const result = await apiPost<{ itemId: string }>("/api/mobile/v1/inventory", { ...fields, ...(id ? { id } : {}) });
      setSavedId(result.itemId);
    } catch (e) { setError(e instanceof ApiError ? e.message : "Could not save. Your details are still here."); }
    finally { saveInFlight.current = false; setBusy(null); }
  }
  return <SafeAreaView edges={["left", "right", "bottom"]} style={{ flex: 1, backgroundColor: colors.background }}>
    <ScreenNavigation title={id ? "Edit home item" : "Add home item"} fallback="/(tabs)/vault" />
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === "ios" ? "padding" : undefined}>
      <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={{ padding: spacing.xl, gap: spacing.lg }}>
        {error ? <Text accessibilityRole="alert" style={{ color: colors.criticalForeground }}>{error}</Text> : null}
        {loading ? <ActivityIndicator color={colors.primary} /> : loadFailed ? <Button label="Try again" onPress={() => { setLoading(true); void load(); }} /> : <>
          {showCapture ? <>
          <Text style={[typography.body, { color: colors.mutedForeground }]}>Photograph the model label. Rezlee fills in the details for you to check, then uses the saved item for recall matching and home questions.</Text>
          <Button label={busy === "scan" ? "Reading label…" : "Scan product label"} disabled={Boolean(busy)} onPress={() => Alert.alert("Scan a product label", "Your selected photo is uploaded for AI extraction. Review the results before saving.", [
            { text: "Take photo", onPress: () => void scan(true) },
            { text: "Choose photo", onPress: () => void scan(false) },
            { text: "Cancel", style: "cancel" },
          ])} />
          <Button label="Find product by barcode" variant="secondary" disabled={Boolean(busy)} onPress={() => setBarcodeOpen(true)} />
          {barcodeOpen ? <BarcodeLookup onApply={applyProduct} onClose={() => setBarcodeOpen(false)} /> : null}
          </> : <Button label="Use another label or barcode" variant="secondary" disabled={Boolean(busy)} onPress={() => setShowCapture(true)} />}
          {notice ? <Text style={[typography.body, { color: colors.mutedForeground }]}>{notice}</Text> : null}
          {!showDetails ? <Button label="Enter details myself" variant="secondary" disabled={Boolean(busy)} onPress={() => { setShowDetails(true); setShowCapture(false); }} /> : null}
          {showDetails ? <>
          <Text style={[typography.section, { color: colors.foreground }]}>{id ? "Your saved details" : "Check your item"}</Text>
          <View style={{ gap: spacing.md }}>
            {([["name", "Item name"], ["brand", "Brand"], ["model_number", "Model number"], ["serial_number", "Serial number (optional)"], ["room_or_area", "Room or area (optional)"], ["category", "Category (optional)"], ["product_barcode", "Product barcode (optional)"]] as const).filter(([key]) => showOptional || ["name", "brand", "model_number"].includes(key) || Boolean(fields[key])).map(([key, label]) =>
              <TextField key={key} label={label} value={fields[key]} editable={!busy} maxLength={200} autoCorrect={false}
                onChangeText={(value) => { setFields((current) => ({ ...current, [key]: value })); setDirty(true); }} />)}
          </View>
          {!showOptional ? <Button label="More details (optional)" variant="secondary" disabled={Boolean(busy)} onPress={() => setShowOptional(true)} /> : null}
          {showOptional || fields.warranty_expires_on ? <DateField label="Warranty expires (optional)" value={fields.warranty_expires_on} optional onChange={value => { if (!busy) { setFields(current => ({...current,warranty_expires_on:value})); setDirty(true); } }} /> : null}
          <Text style={[typography.caption, { color: colors.mutedForeground }]}>You can save incomplete details. Recall matching needs a brand and a model or descriptive item name.</Text>
          <Button label={busy === "save" ? "Saving…" : id ? "Save and check recalls" : "Confirm and check recalls"} disabled={Boolean(busy) || !fields.name.trim()} onPress={() => void save()} />
          </> : null}
          {id ? <Pressable accessibilityRole="button" accessibilityState={{ disabled: Boolean(busy), busy: busy === "delete" }} disabled={Boolean(busy)} onPress={confirmDelete} style={{ minHeight: 44, justifyContent: "center", alignItems: "center" }}><Text style={{ color: colors.criticalForeground }}>{busy === "delete" ? "Deleting…" : "Delete home item"}</Text></Pressable> : null}
        </>}
      </ScrollView>
    </KeyboardAvoidingView>
  </SafeAreaView>;
}
