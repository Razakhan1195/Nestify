import test from "node:test";
import assert from "node:assert/strict";
import {receiptSuggestions} from "../apps/mobile/src/lib/receipt-review";
import {receiptExtractionSchema} from "../src/lib/ai/receipt";
import {scanMobileUpload} from "../src/lib/ai/mobile-scan";
test("receipt review preserves printed foreign currency and cannot invent payment or warranty expiry",()=>{
 const r=receiptSuggestions({document_kind:"receipt",merchant:"Canadian retailer",purchase_date:"2026-02-30",total:20,currency:"USD",items:[{description:"Filter",model:"ABC"}],warranty_expires_on:"2030-01-01",payment_status:"paid"});
 assert.equal(r?.issued_on,"");assert.equal(r?.expires_on,"");
 assert.match(r!.notes,/20.00 USD/);assert.match(r!.notes,/Model: ABC/);
 assert.doesNotMatch(r!.notes,/2030|paid/);
});
test("ambiguous currency, totals and unrelated documents do not become trusted financial data",()=>{
 for(const document_kind of ["invoice","other","uncertain",undefined])assert.equal(receiptSuggestions({document_kind}),null);
 const r=receiptSuggestions({document_kind:"receipt",total:12.345,currency:null,purchase_date:"2024-02-29",items_incomplete:true});
 assert.equal(r?.issued_on,"2024-02-29");assert.doesNotMatch(r!.notes,/Printed total/);
 assert.match(r!.notes,/Some items/);
 assert.match(receiptSuggestions({document_kind:"receipt",total:10})!.notes,/currency not confirmed/);
});
test("receipt extraction bounds item counts and makes uncertainty explicit",()=>{
 const input={document_kind:"receipt",merchant:null,purchase_date:null,currency:null,total:null,items:[],items_incomplete:false,warranty_text:null,review_notes:[]};
 assert.equal(receiptExtractionSchema.parse(input).total,null);
 assert.equal(receiptExtractionSchema.safeParse({...input,items:Array(21).fill({description:"Item",model:null})}).success,false);
});
test("receipt upload reserves once and calls receipt extraction without saving records",async()=>{
 let reserves=0,extracts=0;
 const form=new FormData();form.append("kind","receipt");form.append("file",new File(["%PDF-1.7 synthetic receipt"],"receipt.pdf",{type:"application/pdf"}));
 const response=await scanMobileUpload(new Request("http://localhost/scan",{method:"POST",body:form}),{reserve:async()=>{reserves++;return {ok:true};},extract:async kind=>{assert.equal(kind,"receipt");extracts++;return {document_kind:"receipt"};}});
 assert.equal(response.status,200);assert.equal(reserves,1);assert.equal(extracts,1);
});
