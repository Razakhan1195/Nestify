import { readIncomingPhoneInvite } from "@/lib/phone-invites";
import { setupDrafts } from "@/lib/onboarding-draft";
import { shouldResumeSetup } from "@/lib/onboarding-draft-core";
import { readDeletionReceipt } from "@/lib/account-deletion";
import { Redirect } from "expo-router";
import { useEffect, useState } from "react";
import { Pressable, Text, View } from "react-native";

import { RezleeLoading } from "@/components/RezleeLoading";
import { useAuth } from "@/auth/AuthProvider";
import { ApiError } from "@/lib/api";
import { fetchOnboarding } from "@/lib/onboarding-data";
import { colors, spacing, typography } from "@/theme/tokens";

type Destination = "/onboarding" | "/(tabs)/home" | "/delete-account" | "/household/join" | "/(auth)/welcome";

class EntryRecoveryError extends Error {}

export default function Index() {
  const { session, isLoading } = useAuth();
  if (isLoading) return <LoadingScreen />;
  // Never carry a previous account's resolved destination or recovery state
  // across sign-in/out, including when an earlier read finishes late.
  return <AccountEntry key={session?.user.id ?? "signed-out"} userId={session?.user.id} />;
}

function AccountEntry({ userId }: { userId?: string }) {
  const [destination, setDestination] = useState<Destination | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [attempt, setAttempt] = useState(0);
  useEffect(() => {
    let active = true;
    void (async () => {
      try {
        // Check durable recovery in order. A failed read must not be mistaken
        // for an absent receipt or invitation, and retry repeats every check.
        let receipt;
        try { receipt = await readDeletionReceipt(userId); }
        catch { throw new EntryRecoveryError("Your saved deletion status couldn’t be read. Try again to continue safely."); }
        if (!active) return;
        if (receipt && (!userId || receipt.userId === userId)) { setDestination("/delete-account"); return; }
        if (!userId) { setDestination("/(auth)/welcome"); return; }
        let invitation;
        try { invitation = await readIncomingPhoneInvite(); }
        catch { throw new EntryRecoveryError("Your saved household invitation couldn’t be checked. Try again to return to it."); }
        if (!active) return;
        if (invitation) { setDestination("/household/join"); return; }
        const payload = await fetchOnboarding();
        if (!active) return;
        // Optional setup draft failure must not block an existing household.
        const draft = await setupDrafts.read(userId).catch(() => null);
        if (active) setDestination(!payload.home || shouldResumeSetup(draft, payload.home.id, payload.accessRole) ? "/onboarding" : "/(tabs)/home");
      } catch (loadError) {
        if (active) setError(loadError instanceof ApiError || loadError instanceof EntryRecoveryError
          ? loadError.message : "We could not load your Rezlee setup. Check your connection and try again.");
      }
    })();
    return () => { active = false; };
  }, [userId, attempt]);

  if (destination) return <Redirect href={destination} />;
  if (error) {
    return <View style={{ flex: 1, backgroundColor: colors.background, alignItems: "center", justifyContent: "center", padding: spacing["2xl"], gap: spacing.md }}>
      <Text style={[typography.title, { color: colors.foreground, textAlign: "center" }]}>Could not load Rezlee</Text>
      <Text accessibilityRole="alert" style={[typography.body, { color: colors.mutedForeground, textAlign: "center" }]}>{error}</Text>
      <Pressable accessibilityRole="button" onPress={() => { setError(null); setAttempt(value => value + 1); }} style={{ minHeight: 44, justifyContent: "center" }}>
        <Text style={{ fontSize: 14, fontWeight: "600", color: colors.primary }}>Try again</Text>
      </Pressable>
    </View>;
  }
  return <LoadingScreen />;
}

function LoadingScreen() {
  return <View style={{ flex: 1, alignItems: "center", justifyContent: "center", backgroundColor: colors.background }}>
    <RezleeLoading />
  </View>;
}
