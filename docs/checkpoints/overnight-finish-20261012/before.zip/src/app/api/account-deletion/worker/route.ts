import { validBearer } from "@/lib/security/bearer";
import { runAccountDeletionQueue } from "@/lib/account/deletion";
export const dynamic = "force-dynamic";
export const maxDuration = 300;
export async function GET(request: Request) {
  if (!validBearer(request.headers.get("authorization"), process.env.CRON_SECRET)) return Response.json({ error: "Unauthorized." }, { status: 401 });
  try { return Response.json(await runAccountDeletionQueue(), { headers: { "Cache-Control": "no-store" } }); }
  catch { return Response.json({ error: "Deletion worker could not finish." }, { status: 503 }); }
}
