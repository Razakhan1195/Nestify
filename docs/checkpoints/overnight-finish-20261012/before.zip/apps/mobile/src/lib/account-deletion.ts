import * as SecureStore from "expo-secure-store";
import { apiGet, apiPost, apiDeletionReceipt } from "@/lib/api";

export type DeletionReceipt = { userId: string; requestId: string; receiptToken: string };
export type DeletionStatus = { requestId: string; status: "queued" | "running" | "retry" | "needs_attention" | "completed"; phase: "connections" | "files" | "account"; completedAt: string | null };
export type DeletionPreview = { enabled: boolean; emailCodeAvailable?: boolean; impact?: { homes: number; sharedMemberships: number; joinedHomes: number }; deletion?: DeletionStatus };
const key = "rezlee.account-deletion.v1";
export async function readDeletionReceipt(): Promise<DeletionReceipt | null> {
  const raw = await SecureStore.getItemAsync(key);
  if (!raw) return null;
  const record = JSON.parse(raw);
  if (!record || typeof record.userId !== "string" || !/^[a-f0-9-]{36}$/i.test(record.requestId) || !/^[a-f0-9]{64}$/.test(record.receiptToken)) throw new Error("Deletion receipt could not be read.");
  return record;
}
export async function prepareDeletionReceipt(userId: string, existingRequestId?: string): Promise<DeletionReceipt> {
  const current = await readDeletionReceipt();
  if (current?.userId === userId && (!existingRequestId || current.requestId === existingRequestId)) return current;
  const crypto = await import("expo-crypto");
  const bytes = await crypto.getRandomBytesAsync(32);
  const record = { userId, requestId: existingRequestId ?? crypto.randomUUID(), receiptToken: Array.from(bytes, n => n.toString(16).padStart(2, "0")).join("") };
  await SecureStore.setItemAsync(key, JSON.stringify(record));
  return record;
}
export async function clearDeletionReceipt() { await SecureStore.deleteItemAsync(key); }
export function deletionPreview() { return apiGet<DeletionPreview>("/api/mobile/v1/account/deletion", { timeoutMs: 15_000 }); }
export function submitDeletion(record: DeletionReceipt) { return apiPost<DeletionStatus>("/api/mobile/v1/account/deletion", { userId: record.userId, requestId: record.requestId, receiptToken: record.receiptToken, confirm: "DELETE" }, { timeoutMs: 15_000 }); }
export function deletionStatus(record: DeletionReceipt) { return apiDeletionReceipt<DeletionStatus>({ requestId: record.requestId, receiptToken: record.receiptToken }); }
