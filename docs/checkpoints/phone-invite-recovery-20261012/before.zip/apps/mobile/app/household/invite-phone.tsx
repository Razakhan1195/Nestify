import { useLocalSearchParams, useRouter } from "expo-router";
import { useEffect, useRef, useState } from "react";
import { KeyboardAvoidingView, Platform, ScrollView, Text } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Button } from "@/components/Button";
import { TextField } from "@/components/TextField";
import { ScreenNavigation } from "@/components/ScreenNavigation";
import { QuietAction } from "@/components/Brief";
import { createPhoneInvitation, pendingPhoneInvitation, normalizeInvitePhone, openPhoneInvitation } from "@/lib/phone-invites";
import { colors, typography } from "@/theme/tokens";
export default function InviteByPhone() {
  const params = useLocalSearchParams<{ name?: string; personId?: string }>(), router = useRouter();
  const [name, setName] = useState(params.name ?? ""), [phone, setPhone] = useState("");
  const [member, setMember] = useState<string | null>(null), [busy, setBusy] = useState(false), [error, setError] = useState<string | null>(null), [opened, setOpened] = useState(false);
  const lock = useRef(false);
  const [pendingPersonId, setPendingPersonId] = useState<string | undefined>(params.personId);
  useEffect(() => { let active = true; void pendingPhoneInvitation().then(pending => {
    if (pending && active) { setName(pending.displayName); setPhone(pending.phone); setPendingPersonId(pending.expensePersonId); }
  }).catch(() => { if (active) setError("Couldn’t check unfinished invitations. Retry before preparing another."); }); return () => { active = false; }; }, []);
  async function prepare() {
    const number = normalizeInvitePhone(phone);
    if (lock.current || !number || !name.trim()) return;
    lock.current = true; setBusy(true); setError(null);
    try { const result = await createPhoneInvitation({ displayName: name.trim(), phone: number, ...(pendingPersonId ? { expensePersonId: pendingPersonId } : {}) }); setMember(result.memberId); }
    catch (e) { setError(e instanceof Error ? e.message : "Couldn’t prepare this invitation. Retry with the same details."); }
    finally { lock.current = false; setBusy(false); }
  }
  async function send() { if (!member) return; setError(null); try { await openPhoneInvitation(member); setOpened(true); } catch (e) { setError(e instanceof Error ? e.message : "Couldn’t open Messages."); } }
  return <SafeAreaView style={{ flex: 1, backgroundColor: colors.canvas }}>
    <ScreenNavigation title="Invite by phone" fallback="/household" />
    <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} style={{ flex: 1 }}><ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={{ padding: 20, gap: 20 }}>
      <Text style={[typography.heading, { color: colors.foreground }]}>{member ? "Your invitation is ready" : "Invite them to your household"}</Text>
      {member ? <>
        <Text style={[typography.body, { color: colors.mutedForeground }]}>{opened ? "Messages was opened. Rezlee cannot confirm whether you sent the text. " : "Choose Open Messages to review and send the invitation yourself. "}The link expires in seven days.</Text>
        <Button label="Open Messages" onPress={() => void send()} />
        <QuietAction label="View People and invitations" onPress={() => router.replace("/household")} />
      </> : <>
        <TextField label="Name" value={name} onChangeText={setName} editable={!busy && !pendingPersonId} maxLength={80} />
        <TextField label="Mobile number" value={phone} onChangeText={setPhone} keyboardType="phone-pad" placeholder="(416) 555-0123" editable={!busy} maxLength={24} />
        <Text style={[typography.meta, { color: colors.mutedForeground }]}>Canadian numbers can be entered without +1. For other countries, include the country code.</Text>
        <Button label="Prepare invitation" disabled={!name.trim() || !normalizeInvitePhone(phone)} loading={busy} onPress={() => void prepare()} />
        <QuietAction label="Invite by email instead" onPress={() => router.replace("/household/add")} />
      </>}
      <Text style={[typography.body, { color: colors.mutedForeground }]}>They sign in and request to join. You’ll confirm their account in People before access is granted. Shared expenses and Care are shared; private bills and Vault documents stay private.</Text>
      {error ? <Text accessibilityRole="alert" style={[typography.body, { color: colors.criticalForeground }]}>{error}</Text> : null}
    </ScrollView></KeyboardAvoidingView>
  </SafeAreaView>;
}
