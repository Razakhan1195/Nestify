import { router } from "expo-router";
import Constants from "expo-constants";

import { supabase } from "@/lib/supabase";
import { multipartRequest } from "./multipart-request";

function configuredApiUrl() {
  return process.env.EXPO_PUBLIC_API_URL?.replace(/\/$/, "");
}

function developmentApiUrl() {
  const hostUri = Constants.expoConfig?.hostUri;
  if (!hostUri) return null;

  const withoutProtocol = hostUri.replace(/^https?:\/\//, "");
  const host =
    withoutProtocol.startsWith("[")
      ? withoutProtocol.slice(1, withoutProtocol.indexOf("]"))
      : withoutProtocol.split(":")[0];

  return host ? `http://${host}:3000` : null;
}

function resolveApiUrl() {
  if (__DEV__) {
    return configuredApiUrl() ?? developmentApiUrl();
  }

  return configuredApiUrl();
}

const apiUrl = resolveApiUrl();

if (__DEV__) {
  console.log("[Rezlee API]", apiUrl ?? "not configured");
}

export class ApiError extends Error {
  status: number;

  details?: unknown;

  constructor(message: string, status: number, details?: unknown) {
    super(message);
    this.status = status;
    this.details = details;
  }
}

/**
 * Typed fetch wrapper for the Rezlee mobile-safe API contract
 * (`/api/mobile/v1/*` on the Next.js app). Attaches the current Supabase
 * access token as a Bearer header - the server re-validates it and scopes
 * every query through RLS, so this client never trusts the app itself.
 */
async function getAccessToken() {
  const { data } = await supabase.auth.getSession();
  const accessToken = data.session?.access_token;

  if (!accessToken) {
    throw new ApiError("Not signed in.", 401);
  }

  return accessToken;
}

async function parseErrorBody(response: Response): Promise<never> {
  if (response.status === 423) router.replace("/delete-account");
  const body = await response.json().catch(() => null);
  throw new ApiError(
    body?.error ?? (response.status === 413 ? "Choose a file up to 4 MB, or enter the details manually." : `Request failed with status ${response.status}`),
    response.status,
    body,
  );
}

export async function apiGet<T>(path: string, options?: { timeoutMs?: number }): Promise<T> {
  if (!apiUrl) throw new ApiError("EXPO_PUBLIC_API_URL is not configured.", 500);
  const accessToken = await getAccessToken();
  const controller = options?.timeoutMs ? new AbortController() : null;
  const timeout = controller ? setTimeout(() => controller.abort(), options?.timeoutMs) : null;
  try {
    const response = await fetch(`${apiUrl}${path}`, {
      headers: { Authorization: `Bearer ${accessToken}`, Accept: "application/json" },
      signal: controller?.signal,
    });
    if (!response.ok) return await parseErrorBody(response);
    return await response.json() as T;
  } catch (error) {
    if (controller?.signal.aborted) throw new ApiError("Could not check the latest status. Please try again.", 408);
    throw error;
  } finally { if (timeout) clearTimeout(timeout); }
}

export async function apiPost<T>(
  path: string,
  body?: unknown,
  options?: { timeoutMs?: number },
): Promise<T> {
  if (!apiUrl) {
    throw new ApiError("EXPO_PUBLIC_API_URL is not configured.", 500);
  }

  const accessToken = await getAccessToken();
  const controller = options?.timeoutMs ? new AbortController() : null;
  const timeout = controller
    ? setTimeout(() => controller.abort(), options?.timeoutMs)
    : null;

  let response: Response;
  try {
    response = await fetch(`${apiUrl}${path}`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${accessToken}`,
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: body ? JSON.stringify(body) : undefined,
      signal: controller?.signal,
    });
  } catch (error) {
    if (controller?.signal.aborted) {
      throw new ApiError("This is taking longer than expected. Please try again.", 408);
    }
    throw error;
  } finally {
    if (timeout) clearTimeout(timeout);
  }

  if (!response.ok) {
    return parseErrorBody(response);
  }

  return response.json() as Promise<T>;
}

export async function apiPatch<T>(path: string, body?: unknown, options?: { timeoutMs?: number }): Promise<T> {
  if (!apiUrl) throw new ApiError("EXPO_PUBLIC_API_URL is not configured.", 500);
  const accessToken = await getAccessToken();
  const controller = options?.timeoutMs ? new AbortController() : null;
  const timeout = controller ? setTimeout(() => controller.abort(), options?.timeoutMs) : null;
  try {
    const response = await fetch(`${apiUrl}${path}`, {
      method: "PATCH",
      headers: { Authorization: `Bearer ${accessToken}`, Accept: "application/json", "Content-Type": "application/json" },
      body: body ? JSON.stringify(body) : undefined, signal: controller?.signal,
    });
    if (!response.ok) return await parseErrorBody(response);
    return await response.json() as T;
  } catch (error) {
    if (controller?.signal.aborted) throw new ApiError("Could not confirm the save. Please try again.", 408);
    throw error;
  } finally { if (timeout) clearTimeout(timeout); }
}

export async function apiDelete<T>(path: string): Promise<T> {
  if (!apiUrl) throw new ApiError("EXPO_PUBLIC_API_URL is not configured.", 500);
  const accessToken = await getAccessToken();
  const response = await fetch(`${apiUrl}${path}`, {
    method: "DELETE",
    headers: { Authorization: `Bearer ${accessToken}`, Accept: "application/json" },
  });
  if (!response.ok) return parseErrorBody(response);
  return response.json() as Promise<T>;
}

export async function apiFormPost<T>(path: string, body: FormData, options?: { timeoutMs?: number }): Promise<T> {
  if (!apiUrl) throw new ApiError("EXPO_PUBLIC_API_URL is not configured.", 500);
  const accessToken = await getAccessToken();
  const controller = options?.timeoutMs ? new AbortController() : null;
  const timeout = controller ? setTimeout(() => controller.abort(), options?.timeoutMs) : null;
  try {
    const response = await multipartRequest(`${apiUrl}${path}`, body, {
      headers: { Authorization: `Bearer ${accessToken}`, Accept: "application/json" },
      signal: controller?.signal,
    });
    if (!response.ok) return await parseErrorBody(response);
    return await response.json() as T;
  } catch (error) {
    if (controller?.signal.aborted) throw new ApiError("The upload took too long to confirm. Please try again.", 408);
    throw error;
  } finally { if (timeout) clearTimeout(timeout); }
}

/** Receipt grants access only to deletion status after the Auth account is gone. */
export async function apiDeletionReceipt<T>(receipt: { requestId: string; receiptToken: string }): Promise<T> {
  if (!apiUrl) throw new ApiError("Account status is unavailable.", 503);
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 15_000);
  try {
    const response = await fetch(`${apiUrl}/api/mobile/v1/account/deletion/status`, {
      method: "POST", headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify(receipt), signal: controller.signal,
    });
    if (!response.ok) return await parseErrorBody(response);
    return await response.json() as T;
  } finally { clearTimeout(timeout); }
}
