import * as Crypto from "expo-crypto";
import * as SecureStore from "expo-secure-store";
import { Linking, Platform } from "react-native";
import { apiPost, ApiError } from "./api";
import { supabase } from "./supabase";
export type PhoneInvitationState = { state: "pending" | "awaiting_approval" | "accepted" | "expired" | "unavailable" | "other_household" | "own_household"; homeName?: string; expiresAt?: string };
export function normalizeInvitePhone(value: string) {
  const clean = value.replace(/[\s().-]/g, "");
  if (/^[2-9][0-9]{9}$/.test(clean)) return "+1" + clean;
  if (/^1[2-9][0-9]{9}$/.test(clean)) return "+" + clean;
  return /^\+[1-9][0-9]{7,14}$/.test(clean) ? clean : null;
}
async function ownerKey() {
  const { data } = await supabase.auth.getSession();
  if (!data.session) throw Error("Sign in before inviting someone.");
  return "rezlee-phone-invite-" + data.session.user.id;
}
export async function createPhoneInvitation(input: { displayName: string; phone: string; relationship?: string; expensePersonId?: string }) {
  const key = await ownerKey();
  const saved = await SecureStore.getItemAsync(key);
  const pending = saved ? JSON.parse(saved) : { input, requestId: Crypto.randomUUID(), token: Crypto.randomUUID().replace(/-/g, "") + Crypto.randomUUID().replace(/-/g, "") };
  if (JSON.stringify(pending.input) !== JSON.stringify(input)) throw Error("An earlier invitation needs confirmation. Retry with the same details before creating another.");
  if (!saved) await SecureStore.setItemAsync(key, JSON.stringify(pending));
  let result: { memberId: string; expiresAt: string };
  try { result = await apiPost<typeof result>("/api/mobile/v1/household/phone", { operation: "create", ...input, requestId: pending.requestId, token: pending.token }); }
  catch (e) { if (e instanceof ApiError && e.status >= 400 && e.status < 500) await SecureStore.deleteItemAsync(key); throw e; }
  await SecureStore.setItemAsync(key + "-" + result.memberId, JSON.stringify({ phone: input.phone, token: pending.token }));
  await SecureStore.deleteItemAsync(key);
  return result;
}
export async function openPhoneInvitation(memberId: string) {
  const saved = await SecureStore.getItemAsync((await ownerKey()) + "-" + memberId);
  if (!saved) throw Error("The invitation link is not saved on this device. Cancel this invitation and create a new one to send it.");
  const { phone, token } = JSON.parse(saved);
  const base = (process.env.EXPO_PUBLIC_API_URL || "https://rezlee.com").replace(/\/$/, "");
  const message = "Join my household on Rezlee to keep shared expenses and home tasks together. Sign in and request to join; I’ll confirm it’s you. " + base + "/join-household#token=" + token;
  await Linking.openURL("sms:" + phone + (Platform.OS === "ios" ? "&" : "?") + "body=" + encodeURIComponent(message));
}
export function checkPhoneInvitation(token: string, confirm = false) { return apiPost<PhoneInvitationState>("/api/mobile/v1/household/phone", { operation: confirm ? "request" : "preview", token }); }
export function approvePhoneInvitation(memberId: string, userId: string) { return apiPost<{ ok: true }>("/api/mobile/v1/household/phone", { operation: "approve", memberId, userId }); }
const incoming = "rezlee-incoming-phone-invite";
export async function saveIncomingPhoneInvite(token: string) { if (!/^[a-f0-9]{64}$/.test(token)) throw Error("Invalid invitation link."); await SecureStore.setItemAsync(incoming, token); }
export function readIncomingPhoneInvite() { return SecureStore.getItemAsync(incoming); }
export function clearIncomingPhoneInvite() { return SecureStore.deleteItemAsync(incoming); }

export async function pendingPhoneInvitation(): Promise<{ displayName: string; phone: string; relationship?: string; expensePersonId?: string } | null> {
  const raw = await SecureStore.getItemAsync(await ownerKey());
  return raw ? JSON.parse(raw).input : null;
}
