import { historyDate } from "./manual-history-insights";
import { moneyCents } from "./statement-evidence";

export type BillTarget = {
  id: string; title: string; expectedAmount: string; effectiveDate: string;
  cost: string; notes: string; state: "planned" | "implemented" | "completed" | "abandoned";
  evidenceBillId: string | null; baseline: string; savedAt: string;
  snoozedUntil: string | null;
};
export type OutcomeStatement = {
  id: string; provider: string; account: string; category: string; currency: string;
  amount: number | null; start: string | null; end: string | null; hasOriginal: boolean;
};
export type BillTargetSummary = { state: BillTarget["state"]; title: string; savedAt: string; snoozedUntil: string | null };
export function parseBillTarget(value: unknown): BillTarget | null {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  const v = value as BillTarget;
  if (typeof v.id !== "string" || typeof v.title !== "string" || !v.title.trim() || v.title.length > 120 ||
      typeof v.expectedAmount !== "string" || moneyCents(v.expectedAmount) === null || moneyCents(v.expectedAmount)! < 0 ||
      !historyDate(v.effectiveDate) || typeof v.cost !== "string" || (v.cost !== "" && (moneyCents(v.cost) === null || moneyCents(v.cost)! < 0)) ||
      typeof v.notes !== "string" || v.notes.length > 2000 || !["planned", "implemented", "completed", "abandoned"].includes(v.state) ||
      !(v.evidenceBillId === null || typeof v.evidenceBillId === "string") || typeof v.baseline !== "string" ||
      typeof v.savedAt !== "string" || !Number.isFinite(Date.parse(v.savedAt)) ||
      !(v.snoozedUntil === null || historyDate(v.snoozedUntil))) return null;
  return v;
}
export function billTargetSummary(raw: unknown): BillTargetSummary | null {
  const target = parseBillTarget((raw as Record<string, unknown> | null)?.bill_target);
  return target ? { state: target.state, title: target.title, savedAt: target.savedAt, snoozedUntil: target.snoozedUntil } : null;
}
export function targetNeedsFollowUp(summary: BillTargetSummary | null | undefined, today: string) {
  return Boolean(summary && !["abandoned", "completed"].includes(summary.state) && (!summary.snoozedUntil || summary.snoozedUntil <= today));
}
const normalized = (value: string) => value.trim().toLowerCase();
export function sameOutcomeAccount(a: OutcomeStatement, b: OutcomeStatement) {
  return Boolean(a.provider.trim() && a.account.trim() &&
    normalized(a.provider) === normalized(b.provider) && normalized(a.account) === normalized(b.account) &&
    normalized(a.category) === normalized(b.category) && a.currency === b.currency);
}
function days(b: OutcomeStatement) {
  return historyDate(b.start) && historyDate(b.end) && b.start <= b.end
    ? Math.round((Date.parse(b.end) - Date.parse(b.start)) / 86400000) + 1 : null;
}
function monthlyCycle(b: OutcomeStatement) {
  if (!historyDate(b.start) || !historyDate(b.end)) return false;
  const start = new Date(b.start + "T00:00:00Z");
  const nextMonthLast = new Date(Date.UTC(start.getUTCFullYear(), start.getUTCMonth() + 2, 0)).getUTCDate();
  const next = Date.UTC(start.getUTCFullYear(), start.getUTCMonth() + 1, Math.min(start.getUTCDate(), nextMonthLast));
  return Date.parse(b.end) + 86400000 === next;
}
export function evaluateBillTarget(target: BillTarget, baseline: OutcomeStatement, currentBaseline: string, evidence: OutcomeStatement | null, today: string) {
  const response = (state: string, title: string, detail: string, differenceCents: number | null = null) => ({ state, title, detail, differenceCents });
  if (target.state === "abandoned") return response("abandoned", "Tracking stopped", "Your saved action is kept. Reopen it when you want to check again.");
  if (target.baseline !== currentBaseline) return response("needs_review", "Review the corrected baseline", "The original bill or its reviewed details changed. Review it before using it to check this action.");
  if (target.state === "planned") return response("planned", "Change planned", "Once the provider has applied the change, mark it implemented and check a later statement.");
  if (!historyDate(today) || target.effectiveDate > today) return response("awaiting_evidence", "Waiting for the change to start", "The effective date has not arrived. No result is claimed yet.");
  if (!evidence) return response("awaiting_evidence", "Waiting for a statement", "Upload the next relevant bill, then select it here. This manual account is not being automatically monitored.");
  if (!sameOutcomeAccount(baseline, evidence) || evidence.id === baseline.id) return response("inconclusive", "Choose this account’s later bill", "The evidence must belong to the same provider, service, account and currency as the baseline.");
  const beforeDays = days(baseline), afterDays = days(evidence);
  if (!beforeDays || !afterDays || !baseline.end || !evidence.start || evidence.start <= baseline.end || evidence.start < target.effectiveDate || evidence.start > today) return response("inconclusive", "This period does not establish the result", "Choose a separate service period that starts on or after the effective date. A transition or overlapping period can contain prorated charges.");
  if (!evidence.end || evidence.end > today) return response("inconclusive", "Wait for the full billing period", "This statement’s service period has not finished. Choose a completed period to check the agreed amount.");
  const comparable = beforeDays === afterDays || (monthlyCycle(baseline) && monthlyCycle(evidence) && baseline.start!.slice(8) === evidence.start!.slice(8));
  if (!comparable) return response("inconclusive", "Different billing periods", "These periods do not cover the same billing cycle. Review the originals for proration; the total alone cannot verify the agreed amount.");
  const amount = evidence.amount === null ? null : moneyCents(String(evidence.amount));
  const before = baseline.amount === null ? null : moneyCents(String(baseline.amount));
  if (amount === null || before === null || amount < 0 || before < 0) return response("inconclusive", "Review the saved charges", "Missing charges or a net credit cannot establish a recurring bill amount. Correct the saved details or choose the next ordinary statement.");
  const expected = moneyCents(target.expectedAmount)!;
  if (amount === expected) return response("matched", "Recorded charges match your agreed amount", "This checks the selected statement’s period charges. It does not verify payment, the provider’s agreement or continuing savings. Review the original for one-time adjustments.", amount - before);
  return response("different", "Recorded charges differ from your agreed amount", "Check the original for taxes, proration, extra services or one-time charges before treating this as an error. No provider enquiry is generated.", amount - before);
}

/** Compare the submitted fields after an uncertain write without sending it again. */
export function sameBillTargetDetails(target:BillTarget|null,input:Pick<BillTarget,"title"|"expectedAmount"|"effectiveDate"|"cost"|"notes"|"state"|"evidenceBillId"|"snoozedUntil">){
 if(!target)return false;
 return target.title===input.title.trim() && moneyCents(target.expectedAmount)===moneyCents(input.expectedAmount)
  && target.effectiveDate===input.effectiveDate && target.cost===input.cost && target.notes===input.notes
  && target.state===input.state && target.evidenceBillId===input.evidenceBillId && target.snoozedUntil===input.snoozedUntil;
}
/** Use the same numerical/period rules for the picker and the result. Server revalidates every save. */
export function comparableOutcomeStatements(target:BillTarget,baseline:OutcomeStatement,records:OutcomeStatement[],today:string){
 return records.filter(record=>["matched","different"].includes(evaluateBillTarget({...target,state:"implemented"},baseline,target.baseline,record,today).state));
}
