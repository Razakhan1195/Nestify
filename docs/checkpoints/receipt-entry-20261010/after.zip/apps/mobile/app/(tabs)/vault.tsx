import {EmailImportEntry,useEmailImport} from "@/components/EmailImportEntry";
import {vaultCollectionRows,type VaultCollectionView} from "@/lib/collection-navigation";
import {CollectionPages} from "@/components/CollectionPages";
import { RecallWatchSummary } from "@/components/RecallWatchSummary";
import { CollectionToolbar, CollectionAddSheet, CollectionSearch } from "@/components/CollectionUI";
import {receiptBatches} from "@/lib/receipt-batch";
import {useAuth} from "@/auth/AuthProvider";
import {vaultPending} from "@/lib/vault-pending";
import { Feather } from "@expo/vector-icons";
import { Redirect,useFocusEffect,useRouter } from "expo-router";
import { useCallback,useState } from "react";
import { ActivityIndicator,Pressable,RefreshControl,ScrollView,Text,View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Button } from "@/components/Button";
import { apiGet,ApiError } from "@/lib/api";
import { fetchVault,formatVaultDate,type VaultPayload } from "@/lib/vault-data";
import { colors,layout,spacing,typography } from "@/theme/tokens";
type Filter=VaultCollectionView;
const filters=[{value:"documents",label:"Records"},{value:"items",label:"Home items"},{value:"warranties",label:"Warranties"}] as const;
const choices=[
 {kind:"receipt",icon:"camera",title:"Scan a receipt",detail:"Read a photo, review details and keep the original"},
 {kind:"record",icon:"file-text",title:"Record",detail:"Receipt, policy, manual or other document"},
 {kind:"item",icon:"box",title:"Home item",detail:"Appliance or belonging, with scan options"},
 {kind:"warranty",icon:"shield",title:"Warranty",detail:"Coverage dates and proof of purchase"},
] as const;
function VaultRow({icon,title,detail,tag,onPress}:{icon:keyof typeof Feather.glyphMap;title:string;detail:string;tag?:string;onPress:()=>void}){
 return <Pressable accessibilityRole="button" onPress={onPress} style={({pressed})=>({flexDirection:"row",alignItems:"center",gap:14,paddingVertical:18,opacity:pressed?0.6:1,borderBottomWidth:1,borderBottomColor:colors.border})}>
  <View style={{width:40,height:40,borderRadius:12,backgroundColor:colors.surfaceRaised,alignItems:"center",justifyContent:"center"}}><Feather name={icon} size={19} color={colors.foreground}/></View>
  <View style={{flex:1,gap:4}}>
   <Text style={{fontSize:15,fontWeight:"600",color:colors.foreground}} numberOfLines={2}>{title}</Text>
   <Text style={[typography.caption,{color:colors.mutedForeground}]} numberOfLines={2}>{detail}</Text>
   {tag?<Text style={[typography.caption,{color:colors.warningForeground}]}>{tag}</Text>:null}
  </View><Feather name="chevron-right" size={17} color={colors.mutedForeground}/>
 </Pressable>;
}
export default function VaultScreen(){
 const router=useRouter();
 const {session}=useAuth(),userId=session?.user.id;
 const emailImport=useEmailImport();
 const [batchOwner,setBatchOwner]=useState<string|null>(null),[batchAvailable,setBatchAvailable]=useState<boolean|null>(null);
 useFocusEffect(useCallback(()=>{
  let active=true;setBatchOwner(null);setBatchAvailable(null);
  if(userId){
   void receiptBatches.read(userId).then(batch=>{if(active)setBatchOwner(batch?userId:null);}).catch(()=>{if(active)setBatchOwner(userId);});
   // A failed capability check is not a disabled feature. The batch screen
   // verifies availability again before allowing any upload or save.
   void apiGet<{receiptBatch?:boolean}>("/api/mobile/v1/vault/records?capabilities=1",{timeoutMs:10000})
    .then(caps=>{if(active)setBatchAvailable(caps.receiptBatch===true);}).catch(()=>{});
  }
  return()=>{active=false;};
 },[userId]));
 const [pendingOwner,setPendingOwner]=useState<string|null>(null);
 useFocusEffect(useCallback(()=>{let active=true;if(userId)void vaultPending.read(userId).then(key=>{if(active)setPendingOwner(key?userId:null);}).catch(()=>{if(active)setPendingOwner(userId);});return()=>{active=false;};},[userId]));
 const [payload,setPayload]=useState<VaultPayload|null>(null),[filter,setFilter]=useState<Filter>("documents");
 const [queries,setQueries]=useState<Record<Filter,string>>({documents:"",items:"",warranties:""});
 const [adding,setAdding]=useState(false),[loading,setLoading]=useState(true),[refreshing,setRefreshing]=useState(false),[error,setError]=useState<string|null>(null);
 const load=useCallback(async(refresh=false)=>{
  if(refresh)setRefreshing(true);
  try{setPayload(await fetchVault());setError(null);}catch(e){setError(e instanceof ApiError?e.message:"Could not load Vault. Please try again.");}
  finally{setLoading(false);setRefreshing(false);}
 },[]);
 useFocusEffect(useCallback(()=>{void load();},[load]));
 function add(kind:string){
  setAdding(false);
  if(kind==="item")router.push("/inventory-item");
  else router.push({pathname:"/vault-record",params:{kind}});
 }
 if(loading)return <SafeAreaView edges={["left", "right"]} style={{flex:1,backgroundColor:colors.canvas,justifyContent:"center"}}><ActivityIndicator color={colors.primary}/></SafeAreaView>;
 if(payload?.needsOnboarding)return <Redirect href="/onboarding"/>;
 const data=payload&&!payload.needsOnboarding?payload:null;
 const hasEntries=Boolean(data?.documents.length||data?.items.length);
 return <SafeAreaView edges={["left", "right"]} style={{flex:1,backgroundColor:colors.canvas}}>
  <ScrollView contentInsetAdjustmentBehavior="never" automaticallyAdjustContentInsets={false} keyboardShouldPersistTaps="handled" refreshControl={<RefreshControl refreshing={refreshing} onRefresh={()=>void load(true)} tintColor={colors.primary}/>} contentContainerStyle={{paddingHorizontal:layout.screenHorizontal,paddingTop:layout.screenTop,paddingBottom:spacing["4xl"],gap:layout.sectionGap}}>
   <CollectionToolbar title="Vault" description="Records, belongings and coverage." label="Add to Vault" onAdd={()=>setAdding(true)}/>
   <EmailImportEntry destination={emailImport}/>
   {userId&&pendingOwner===userId?<VaultRow icon="upload-cloud" title="Finish record save" detail="Check and finish an earlier save before adding another copy." onPress={()=>router.push("/vault-save-resume")}/>:null}
   {userId&&batchOwner===userId?<VaultRow icon="layers" title="Continue receipt batch" detail="Review unfinished files and check saved receipts." onPress={()=>router.push("/receipt-batch")}/>:null}
   {error?<View style={{gap:8}}><Text accessibilityRole="alert" style={{color:colors.criticalForeground}}>{error}</Text><Pressable accessibilityRole="button" onPress={()=>void load()} style={{minHeight:44,justifyContent:"center"}}><Text style={{color:colors.primary}}>Try again</Text></Pressable></View>:null}
   {data?.summary.expiringSoonCount?<Pressable accessibilityRole="button" onPress={()=>{setQueries(previous=>({...previous,warranties:""}));setFilter("warranties");}} style={{flexDirection:"row",gap:10,alignItems:"center",minHeight:44}}><Feather name="clock" size={17} color={colors.warningForeground}/><Text style={[typography.meta,{color:colors.foreground,flex:1}]}>{data.summary.expiringSoonCount} coverage date(s) coming up</Text><Feather name="chevron-right" size={16} color={colors.mutedForeground}/></Pressable>:null}
   {data?<CollectionPages label="Vault views" options={filters} selected={filter} onSelect={setFilter} renderPage={page=>{
    const query=queries[page],needle=query.trim().toLowerCase();
    const {documents,items}=vaultCollectionRows(data.documents,data.items,page,query);
    const empty=!documents.length&&!items.length;
    return <View style={{gap:18}}>
     {hasEntries?<View style={{gap:4}}>
      <CollectionSearch label={page==="warranties"?"Search warranties":page==="documents"?"Search records":"Search home items"} placeholder={page==="warranties"?"Search coverage and warranty records":page==="documents"?"Search your records":"Search items, brands or models"} value={query} onChangeText={value=>setQueries(previous=>({...previous,[page]:value}))}/>
     </View>:null}
     {page==="warranties"?<Text style={[typography.meta,{color:colors.mutedForeground}]}>Warranty documents and saved item coverage, together. Recorded dates do not guarantee a claim is covered.</Text>:null}
     {page==="items"&&!needle?<RecallWatchSummary itemCount={data.items.length}/>:null}
     {empty&&!error?<View style={{paddingVertical:28,gap:12,alignItems:"center"}}>
      <Text accessibilityRole="header" style={[typography.section,{color:colors.foreground,textAlign:"center"}]}>{needle?"No matching entries":page==="warranties"?"Keep your coverage handy":page==="items"?"Keep track of what you own":"Your important details, together"}</Text>
      <Text style={[typography.body,{color:colors.mutedForeground,textAlign:"center"}]}>{needle?"Try another name or clear your search.":page==="warranties"?"Save warranty proof or add coverage dates to a home item. Both will appear here.":page==="items"?"Save an appliance or belonging with its model, receipt and coverage.":"Save receipts, policies and important documents so they’re easy to find later."}</Text>
      {!needle?<Button label={page==="items"?"Add a home item":page==="warranties"?"Add a warranty":"Add a record"} onPress={()=>add(page==="items"?"item":page==="warranties"?"warranty":"record")}/>:null}
     </View>:null}
     {documents.length?<View>{page==="warranties"?<Text accessibilityRole="header" style={[typography.section,{color:colors.foreground}]}>Warranty documents</Text>:null}{documents.map(d=><VaultRow key={d.id} icon={d.category==="Warranty"?"shield":"file-text"} title={d.title} detail={d.category+" · "+(d.hasFile?"File attached":"Details saved")} tag={d.expires_on?"Expires "+formatVaultDate(d.expires_on):undefined} onPress={()=>router.push({pathname:"/vault-record",params:{id:d.id}})}/>)}</View>:null}
     {items.length?<View>{page==="warranties"?<Text accessibilityRole="header" style={[typography.section,{color:colors.foreground}]}>Item coverage</Text>:null}{items.map(i=><VaultRow key={i.id} icon="box" title={i.name} detail={[i.brand,i.model_number,i.room_or_area].filter(Boolean).join(" · ")||i.category||"Home item"} tag={i.warranty_expires_on?(i.warrantyStatus==="expired"?"Coverage expired ":"Coverage until ")+formatVaultDate(i.warranty_expires_on):undefined} onPress={()=>router.push({pathname:"/inventory-item",params:{id:i.id}})}/>)}</View>:null}
    </View>;
   }}/>:null}
  </ScrollView>
  <CollectionAddSheet title="Add to Vault" visible={adding} onClose={()=>setAdding(false)} choices={[...(emailImport?[{key:"email",title:"Import from email",detail:"Review receipts, warranties and home bills.",icon:"mail" as const,onPress:()=>router.push(emailImport)}]:[]),...choices.map(c=>({key:c.kind,title:c.title,detail:c.detail,icon:c.icon,onPress:()=>add(c.kind)})),...(batchAvailable!==false?[{key:"receipts",title:"Several receipts",detail:"Choose up to five files to review.",icon:"layers" as const,onPress:()=>router.push("/receipt-batch")}]:[])]}/>
 </SafeAreaView>;
}
