import { createContext,useCallback,useContext,useEffect,useState,type ReactNode } from "react";
import { AppState,Pressable,View,Text } from "react-native";
import { Feather } from "@expo/vector-icons";
import { useRootNavigationState,useRouter } from "expo-router";
import { useAuth } from "@/auth/AuthProvider";
import { useAppLock } from "@/auth/AppLockProvider";
import { fetchNotifications } from "@/lib/notification-data";
import { registerPushNotifications, getInitialProviderNotificationHref, addProviderNotificationResponseListener, clearNotificationResponse } from "@/lib/push-notifications";
import { colors } from "@/theme/tokens";
const Context=createContext({unread:0,refresh:async()=>{}});
export const useNotifications=()=>useContext(Context);
export function AppNotifications({children}:{children:ReactNode}) {
 const {session}=useAuth(),{state}=useAppLock(),router=useRouter(),navigation=useRootNavigationState();
 const uid=session?.user.id;const ready=Boolean(uid&&state.ready&&!state.locked&&state.userId===uid&&navigation?.key);
 const [count,setCount]=useState<{user:string;value:number}|null>(null);
 const refresh=useCallback(async()=>{if(!uid||!ready)return;try{const p=await fetchNotifications();setCount({user:uid,value:p.unread});}catch{/* The inbox exposes a retry without an intrusive banner on every tab. */}},[uid,ready]);
 useEffect(()=>{
  if(!ready)return;let active=true;
  const open=(href:string)=>{if(active){router.push(href as never);void clearNotificationResponse();void refresh();}};
  const listener=addProviderNotificationResponseListener(open);
  void getInitialProviderNotificationHref().then(href=>{if(href)open(href);}).catch(()=>{});
  const check=()=>{void refresh();void registerPushNotifications({requestPermission:false}).catch(()=>{});};
  check();
  const foreground=AppState.addEventListener("change",s=>{if(s==="active")check();});
  const timer=setInterval(()=>{if(AppState.currentState==="active")void refresh();},60000);
  return()=>{active=false;listener.remove();foreground.remove();clearInterval(timer);};
 },[ready,uid,refresh,router]);
 return <Context.Provider value={{unread:count&&count.user===uid?count.value:0,refresh}}>{children}</Context.Provider>;
}
export function NotificationBell() {
 const {unread}=useNotifications(),router=useRouter();
 return <Pressable accessibilityRole="button" accessibilityLabel={unread?"Notifications, "+unread+" unread":"Notifications"} onPress={()=>router.push("/notifications")} style={({pressed})=>({width:44,height:44,alignItems:"center",justifyContent:"center",opacity:pressed?0.6:1})}>
  <Feather name="bell" size={21} color={colors.primary}/>
  {unread>0?<View style={{position:"absolute",top:2,right:0,minWidth:17,height:17,paddingHorizontal:3,borderRadius:9,backgroundColor:colors.primary,alignItems:"center",justifyContent:"center"}}><Text style={{fontSize:10,fontWeight:"700",color:colors.background}}>{unread>99?"99+":unread}</Text></View>:null}
 </Pressable>;
}
