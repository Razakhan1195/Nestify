import { notificationResponseTarget, type NotificationResponseTarget } from "./notification-routing";
import Constants from "expo-constants";
import * as Device from "expo-device";
import * as Notifications from "expo-notifications";
import { Platform } from "react-native";

import { apiPost } from "@/lib/api";

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowBanner: true,
    shouldShowList: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
  }),
});

export async function registerPushNotifications(input: {
  requestPermission: boolean;
}) {
  if (!Device.isDevice) return null;

  if (Platform.OS === "android") {
    await Notifications.setNotificationChannelAsync("home-reminders", {name:"Home reminders",importance:Notifications.AndroidImportance.DEFAULT});
    await Notifications.setNotificationChannelAsync("recall-watch", {
      name: "Product recall notices",
      importance: Notifications.AndroidImportance.DEFAULT,
    });
    await Notifications.setNotificationChannelAsync("provider-sync", {
      name: "Bill connection updates",
      importance: Notifications.AndroidImportance.HIGH,
      vibrationPattern: [0, 200, 100, 200],
    });
  }

  let permissions = await Notifications.getPermissionsAsync();
  if (
    permissions.status !== "granted" &&
    input.requestPermission &&
    permissions.canAskAgain
  ) {
    permissions = await Notifications.requestPermissionsAsync();
  }

  if (permissions.status !== "granted") return null;

  const projectId =
    Constants.expoConfig?.extra?.eas?.projectId ??
    Constants.easConfig?.projectId;

  if (!projectId) return null;

  const token = (
    await Notifications.getExpoPushTokenAsync({ projectId })
  ).data;

  await apiPost<{ ok: true }>("/api/mobile/v1/push-tokens", {
    token,
    platform: Platform.OS,
  });

  return token;
}

function providerHrefFromResponse(
  response: Notifications.NotificationResponse | null,
) {
  const href = response?.notification.request.content.data?.mobileHref;
  return typeof href === "string" &&
    (/^\/(provider|bill|care|shared)\/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(href) || ["/shared","/recalls","/notifications","/(tabs)/bills","/(tabs)/care"].includes(href))
    ? href
    : null;
}

export async function getInitialProviderNotificationHref() {
  return providerHrefFromResponse(
    await Notifications.getLastNotificationResponseAsync(),
  );
}

export function addProviderNotificationResponseListener(
  onProviderHref: (href: string) => void,
) {
  return Notifications.addNotificationResponseReceivedListener((response) => {
    const href = providerHrefFromResponse(response);
    if (href) onProviderHref(href);
  });
}

export async function clearNotificationResponse() {await Notifications.clearLastNotificationResponseAsync();}
export async function unregisterPushNotifications() {
 if(!Device.isDevice)return;
 const permissions=await Notifications.getPermissionsAsync();if(permissions.status!=="granted")return;
 const projectId=Constants.expoConfig?.extra?.eas?.projectId??Constants.easConfig?.projectId;if(!projectId)return;
 const token=(await Notifications.getExpoPushTokenAsync({projectId})).data;
 const {supabase}=await import("./supabase");
 await supabase.from("device_push_tokens").update({enabled:false}).eq("expo_push_token",token);
 await clearNotificationResponse();
}

export async function getInitialNotificationTarget() {
 return notificationResponseTarget(await Notifications.getLastNotificationResponseAsync());
}
export function addNotificationTargetListener(open:(target:NotificationResponseTarget)=>void) {
 return Notifications.addNotificationResponseReceivedListener(response=>{const target=notificationResponseTarget(response);if(target)open(target);});
}
