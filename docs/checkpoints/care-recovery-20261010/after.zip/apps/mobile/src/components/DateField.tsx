import { Feather } from "@expo/vector-icons";
import { useMemo, useState } from "react";
import { Modal, Pressable, Text, View } from "react-native";

import { colors, radii, spacing, typography } from "@/theme/tokens";

type DateFieldProps = {
  label: string;
  value: string;
  onChange: (value: string) => void;
  optional?: boolean;
  disabled?: boolean;
  placeholder?: string;
};

const weekdays = ["S", "M", "T", "W", "T", "F", "S"];

function parseIsoDate(value: string) {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
  if (!match) return null;
  const year = Number(match[1]);
  const month = Number(match[2]) - 1;
  const day = Number(match[3]);
  const date = new Date(year, month, day);
  if (
    date.getFullYear() !== year ||
    date.getMonth() !== month ||
    date.getDate() !== day
  ) {
    return null;
  }
  return date;
}

function toIsoDate(date: Date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function formatDisplayDate(value: string) {
  const date = parseIsoDate(value);
  if (!date) return null;
  return new Intl.DateTimeFormat("en-CA", {
    day: "numeric",
    month: "short",
    year: "numeric",
  }).format(date);
}

function monthGrid(anchor: Date) {
  const year = anchor.getFullYear();
  const month = anchor.getMonth();
  const first = new Date(year, month, 1);
  const start = new Date(year, month, 1 - first.getDay());

  return Array.from({ length: 42 }, (_, index) => {
    const date = new Date(start);
    date.setDate(start.getDate() + index);
    return date;
  });
}

export function DateField({
  label,
  value,
  onChange,
  optional = false,
  disabled = false,
  placeholder = "Choose a date",
}: DateFieldProps) {
  const selectedDate = parseIsoDate(value);
  const [open, setOpen] = useState(false);
  const [visibleMonth, setVisibleMonth] = useState(
    selectedDate ?? new Date(),
  );

  const days = useMemo(() => monthGrid(visibleMonth), [visibleMonth]);
  const monthLabel = new Intl.DateTimeFormat("en-CA", {
    month: "long",
    year: "numeric",
  }).format(visibleMonth);
  const displayValue = formatDisplayDate(value);

  function openPicker() {
    if (disabled) return;
    setVisibleMonth(selectedDate ?? new Date());
    setOpen(true);
  }

  function moveMonth(delta: number) {
    setVisibleMonth(
      (current) => new Date(current.getFullYear(), current.getMonth() + delta, 1),
    );
  }

  function chooseDate(date: Date) {
    if (disabled) return;
    onChange(toIsoDate(date));
    setOpen(false);
  }

  return (
    <View style={{ gap: 6 }}>
      <Text style={{ fontSize: 13, fontWeight: "600", color: colors.mutedForeground }}>
        {label}
      </Text>
      <Pressable
        accessibilityRole="button"
        accessibilityLabel={label}
        disabled={disabled}
        accessibilityState={{ disabled }}
        onPress={openPicker}
        style={({ pressed }) => ({
          minHeight: 48,
          borderRadius: radii.md,
          borderWidth: 1,
          borderColor: colors.border,
          backgroundColor: colors.card,
          paddingHorizontal: 14,
          flexDirection: "row",
          alignItems: "center",
          justifyContent: "space-between",
          gap: spacing.md,
          opacity: pressed ? 0.78 : 1,
        })}
      >
        <Text
          style={{
            flex: 1,
            fontSize: 16,
            color: displayValue ? colors.foreground : colors.mutedForeground,
          }}
        >
          {displayValue ?? placeholder}
        </Text>
        <Feather name="calendar" size={18} color={colors.mutedForeground} />
      </Pressable>

      <Modal
        visible={open && !disabled}
        transparent
        animationType="fade"
        onRequestClose={() => setOpen(false)}
      >
        <Pressable
          onPress={() => setOpen(false)}
          style={{
            flex: 1,
            backgroundColor: "rgba(34, 48, 43, 0.35)",
            justifyContent: "flex-end",
          }}
        >
          <Pressable
            onPress={() => undefined}
            style={{
              backgroundColor: colors.surfaceRaised,
              borderTopLeftRadius: radii["3xl"],
              borderTopRightRadius: radii["3xl"],
              paddingHorizontal: spacing.xl,
              paddingTop: spacing.lg,
              paddingBottom: spacing["3xl"],
              gap: spacing.lg,
            }}
          >
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "space-between",
              }}
            >
              <View style={{ gap: 2 }}>
                <Text style={[typography.section, { color: colors.foreground }]}>
                  {label}
                </Text>
                <Text style={[typography.caption, { color: colors.mutedForeground }]}>
                  {displayValue ?? "No date selected"}
                </Text>
              </View>
              <Pressable
                accessibilityLabel="Close date picker"
                onPress={() => setOpen(false)}
                style={{
                  width: 40,
                  height: 40,
                  borderRadius: radii.full,
                  alignItems: "center",
                  justifyContent: "center",
                  backgroundColor: colors.secondary,
                }}
              >
                <Feather name="x" size={18} color={colors.secondaryForeground} />
              </Pressable>
            </View>

            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "space-between",
              }}
            >
              <Pressable
                accessibilityLabel="Previous month"
                onPress={() => moveMonth(-1)}
                style={{
                  width: 44,
                  height: 44,
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <Feather name="chevron-left" size={20} color={colors.foreground} />
              </Pressable>
              <Text style={{ fontSize: 16, fontWeight: "700", color: colors.foreground }}>
                {monthLabel}
              </Text>
              <Pressable
                accessibilityLabel="Next month"
                onPress={() => moveMonth(1)}
                style={{
                  width: 44,
                  height: 44,
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <Feather name="chevron-right" size={20} color={colors.foreground} />
              </Pressable>
            </View>

            <View style={{ gap: spacing.xs }}>
              <View style={{ flexDirection: "row" }}>
                {weekdays.map((day, index) => (
                  <View
                    key={`${day}-${index}`}
                    style={{ width: "14.2857%", alignItems: "center", paddingVertical: 6 }}
                  >
                    <Text style={[typography.caption, { color: colors.mutedForeground }]}>
                      {day}
                    </Text>
                  </View>
                ))}
              </View>
              <View style={{ flexDirection: "row", flexWrap: "wrap" }}>
                {days.map((date) => {
                  const iso = toIsoDate(date);
                  const selected = iso === value;
                  const inMonth = date.getMonth() === visibleMonth.getMonth();
                  const today = iso === toIsoDate(new Date());

                  return (
                    <View key={iso} style={{ width: "14.2857%", alignItems: "center" }}>
                      <Pressable
                        accessibilityRole="button"
                        accessibilityLabel={new Intl.DateTimeFormat("en-CA", {
                          day: "numeric",
                          month: "long",
                          year: "numeric",
                        }).format(date)}
                        onPress={() => chooseDate(date)}
                        style={{
                          width: 40,
                          height: 40,
                          borderRadius: radii.full,
                          alignItems: "center",
                          justifyContent: "center",
                          backgroundColor: selected ? colors.primary : "transparent",
                          borderWidth: today && !selected ? 1 : 0,
                          borderColor: colors.borderStrong,
                        }}
                      >
                        <Text
                          style={{
                            fontSize: 14,
                            fontWeight: selected || today ? "700" : "500",
                            color: selected
                              ? colors.primaryForeground
                              : inMonth
                                ? colors.foreground
                                : colors.mutedForeground,
                            opacity: inMonth || selected ? 1 : 0.45,
                          }}
                        >
                          {date.getDate()}
                        </Text>
                      </Pressable>
                    </View>
                  );
                })}
              </View>
            </View>

            <View style={{ flexDirection: "row", gap: spacing.sm }}>
              <Pressable
                onPress={() => chooseDate(new Date())}
                style={{
                  flex: 1,
                  minHeight: 46,
                  borderRadius: radii.md,
                  alignItems: "center",
                  justifyContent: "center",
                  backgroundColor: colors.secondary,
                }}
              >
                <Text style={{ fontSize: 14, fontWeight: "700", color: colors.secondaryForeground }}>
                  Today
                </Text>
              </Pressable>
              {optional ? (
                <Pressable
                  onPress={() => {
                    onChange("");
                    setOpen(false);
                  }}
                  style={{
                    flex: 1,
                    minHeight: 46,
                    borderRadius: radii.md,
                    alignItems: "center",
                    justifyContent: "center",
                    backgroundColor: colors.secondary,
                  }}
                >
                  <Text style={{ fontSize: 14, fontWeight: "700", color: colors.secondaryForeground }}>
                    Clear
                  </Text>
                </Pressable>
              ) : null}
            </View>
          </Pressable>
        </Pressable>
      </Modal>
    </View>
  );
}
