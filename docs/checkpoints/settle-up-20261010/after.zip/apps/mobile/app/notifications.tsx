import { useCallback,useState } from "react";
import { Redirect,useFocusEffect,useRouter } from "expo-router";
import { ActivityIndicator,Pressable,RefreshControl,ScrollView,Text,View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Feather } from "@expo/vector-icons";
import { useAuth } from "@/auth/AuthProvider";
import { ScreenNavigation } from "@/components/ScreenNavigation";
import { BriefHeading,QuietAction,ReadNotice } from "@/components/Brief";
import { useNotifications } from "@/components/AppNotifications";
import { fetchNotifications,readNotification,readAllNotifications,type NotificationsPayload,type AppNotification } from "@/lib/notification-data";
import { colors,layout,spacing,typography } from "@/theme/tokens";
const labels={shared_expenses:"Shared expenses",connections:"Connections",bills:"Bills",care:"Care",recalls:"Recalls"};
export default function NotificationsScreen() {
 const {session,isLoading}=useAuth(),router=useRouter(),{refresh}=useNotifications();
 const [data,setData]=useState<NotificationsPayload|null>(null),[error,setError]=useState<string|null>(null),[busy,setBusy]=useState(false),[onlyUnread,setOnlyUnread]=useState(false);
 const load=useCallback(async()=>{try{setData(await fetchNotifications());setError(null);void refresh();}catch{setError("Your notifications couldn’t be loaded. Your saved records are still available.");}},[refresh]);
 useFocusEffect(useCallback(()=>{let active=true;void fetchNotifications().then(p=>{if(active){setData(p);setError(null);void refresh();}}).catch(()=>{if(active)setError("Your notifications couldn’t be loaded.");});return()=>{active=false;};},[refresh]));
 async function open(n:AppNotification){setError(null);try{await readNotification(n.id);setData(p=>p?{...p,unread:Math.max(0,p.unread-(n.status==="unread"?1:0)),items:p.items.map(x=>x.id===n.id?{...x,status:"read"}:x)}:p);void refresh();if(n.href)router.push(n.href as never);}catch{setError("Could not open this notification. Please try again.");}}
 async function markAll(){if(!data||busy)return;setBusy(true);try{await readAllNotifications(data.asOf);await load();}catch{setError("Could not mark notifications read.");}finally{setBusy(false);}}
 async function more(){if(!data?.nextBefore||busy)return;setBusy(true);try{const next=await fetchNotifications(data.nextBefore);setData(p=>p?{...next,items:[...p.items,...next.items]}:next);}catch{setError("Could not load older notifications.");}finally{setBusy(false);}}
 if(!isLoading&&!session)return <Redirect href="/(auth)/login"/>;
 const items=data?.items.filter(n=>!onlyUnread||n.status==="unread")??[];
 return <SafeAreaView edges={["left","right","bottom"]} style={{flex:1,backgroundColor:colors.background}}>
  <ScreenNavigation title="Notifications" fallback="/(tabs)/home"/>
  <ScrollView refreshControl={<RefreshControl refreshing={busy} onRefresh={()=>void load()}/>} contentContainerStyle={{padding:layout.screenHorizontal,paddingBottom:48,gap:spacing.lg}}>
   <BriefHeading title="Your updates, together." detail="Shared expenses, bills, care, recalls and connection updates. Opening an update won’t mark a bill paid or a task done."/>
   <View style={{flexDirection:"row",flexWrap:"wrap",gap:8}}><QuietAction label="Notification settings" onPress={()=>router.push("/notification-settings")}/>{data?.unread?<QuietAction label="Mark all read" disabled={busy} onPress={()=>void markAll()}/>:null}<QuietAction label={onlyUnread?"Show all":"Unread only"} onPress={()=>setOnlyUnread(v=>!v)}/></View>
   {error?<ReadNotice message={error} onRetry={()=>void load()}/>:null}
   {!data&&!error?<ActivityIndicator accessibilityLabel="Loading notifications" color={colors.primary}/>:null}
   {data&&!items.length?<View style={{paddingVertical:30,gap:12}}><Feather name="bell" size={28} color={colors.primary}/><Text style={[typography.section,{color:colors.foreground}]}>{onlyUnread?"You’re all caught up":"No updates yet"}</Text><Text style={[typography.body,{color:colors.mutedForeground}]}>Useful updates appear here when there’s something to review. Push notifications are optional.</Text></View>:null}
   {items.map(n=><Pressable key={n.id} accessibilityRole="button" accessibilityLabel={(n.status==="unread"?"Unread. ":"")+n.title} onPress={()=>void open(n)} style={({pressed})=>({padding:18,borderRadius:16,borderWidth:1,borderColor:colors.border,backgroundColor:pressed?colors.accent:n.status==="unread"?colors.surfaceSubtle:colors.surfaceRaised,gap:7})}>
    <View style={{flexDirection:"row",alignItems:"center",gap:8}}>{n.status==="unread"?<View style={{width:7,height:7,borderRadius:4,backgroundColor:colors.primary}}/>:null}<Text style={[typography.caption,{color:colors.mutedForeground,flex:1}]}>{labels[n.category]} · {new Date(n.createdAt).toLocaleDateString("en-CA",{month:"short",day:"numeric"})}</Text>{n.href?<Feather name="chevron-right" size={17} color={colors.primary}/>:null}</View>
    <Text style={[typography.body,{fontWeight:"600",color:colors.foreground}]}>{n.title}</Text>{n.body?<Text style={[typography.meta,{color:colors.mutedForeground}]}>{n.body}</Text>:null}
   </Pressable>)}
   {data?.nextBefore?<QuietAction label={busy?"Loading…":"Load older updates"} disabled={busy} onPress={()=>void more()}/>:null}
   {data?.items.length?<Text style={[typography.caption,{color:colors.mutedForeground}]}>Updates from the last 30 days. Expired verification requests and handled reminders are removed automatically.</Text>:null}
  </ScrollView>
 </SafeAreaView>;
}
