import { useFocusEffect,useRouter } from "expo-router";
import {useCallback,useRef,useState} from "react";
import {Text,View} from "react-native";
import {Button} from "@/components/Button";
import {SharedStartCard} from "@/components/SharedStartCard";
import {sharedLedgerStage,sharedEntryContext} from "@/lib/shared-ledger-presentation";
import {BriefRow,QuietAction} from "@/components/Brief";
import {SharedBalances} from "@/components/SharedBalances";
import {SharedFrame,SharedLoading,SharedNotice,sharedStyles as s,useSharedLedger} from "@/components/SharedExpenseUI";
import {fetchSharedExpenses,pendingSharedSave,saveSharedExpense,sharedDate,type PendingSharedSave} from "@/lib/shared-expenses";
import {sharedMoney} from "@/lib/shared-expense-math";
import {colors,typography} from "@/theme/tokens";
import {ApiError} from "@/lib/api";

export default function SharedExpenses({embedded=false,inline=false}:{embedded?:boolean;inline?:boolean}){
 const router=useRouter(),{data,setData,error,busy,load}=useSharedLedger();
 const [checkedPending,setCheckedPending]=useState(false);
 const [pendingCheckError,setPendingCheckError]=useState<string|null>(null);
 const [checkingPending,setCheckingPending]=useState(true);
 const pendingCheckVersion=useRef(0);
 const pendingCheckRunning=useRef(false);
 const [pending,setPending]=useState<PendingSharedSave|null>(null),[saveError,setSaveError]=useState<string|null>(null),[working,setWorking]=useState(false),[moreBusy,setMoreBusy]=useState(false);
 const checkPending=useCallback(async()=>{
  if(pendingCheckRunning.current)return;
  pendingCheckRunning.current=true;
  const version=++pendingCheckVersion.current;
  setCheckingPending(true);setCheckedPending(false);setPendingCheckError(null);
  try{
   const saved=await pendingSharedSave();
   if(version===pendingCheckVersion.current){setPending(saved);setCheckedPending(true);}
  }catch{
   if(version===pendingCheckVersion.current)setPendingCheckError("We couldn’t check your previous save. Try again before adding another expense.");
  }finally{
   if(version===pendingCheckVersion.current){pendingCheckRunning.current=false;setCheckingPending(false);}
  }
 },[]);
 useFocusEffect(useCallback(()=>{
  void checkPending();
  return()=>{pendingCheckVersion.current++;pendingCheckRunning.current=false;};
 },[checkPending]));
 async function recover(){
  if(!pending||working)return;setWorking(true);setSaveError(null);
  try{await saveSharedExpense(pending.homeId,pending.command);setPending(null);await load();}
  catch(e){setSaveError(e instanceof ApiError?e.message:"Could not confirm the save. Try again.");setPending(await pendingSharedSave().catch(()=>pending));}
  finally{setWorking(false);}
 }
 async function more(){
  if(!data?.nextCursor||moreBusy)return;setMoreBusy(true);
  try{const next=await fetchSharedExpenses({before:data.nextCursor});setData(old=>old&&old.home.id===next.home.id?{...next,entries:[...old.entries,...next.entries.filter(e=>!old.entries.some(v=>v.id===e.id))]}:old);}
  catch{setSaveError("Could not load more history. Your entries are still saved.");}
  finally{setMoreBusy(false);}
 }
 const ready=Boolean(data&&!error&&!busy&&checkedPending&&!pending&&!working);
 const stage=data?sharedLedgerStage(data):null;
 return <SharedFrame title="Shared expenses" embedded={embedded} inline={inline} fallback="/(tabs)/bills">
  {inline?<View style={{flexDirection:"row",alignItems:"center",gap:12}}><Text accessibilityRole="header" style={[typography.title,{flex:1,color:colors.foreground}]}>Shared expenses</Text>{stage&&stage!=="start"?<QuietAction label="Add expense" disabled={!ready} onPress={()=>router.push("/shared/edit")}/>:null}</View>:null}
  {embedded?<View style={{gap:6}}><Text accessibilityRole="header" style={[typography.heading,{color:colors.foreground}]}>Bills</Text><Text style={s.label}>Your household’s shared expenses. Private bills stay with their account owner.</Text></View>:null}
  {error?<SharedNotice message={error} onRetry={()=>void load()} busy={busy}/>:null}
  {busy&&!data?<SharedLoading/>:null}
  {checkingPending&&data?<Text accessibilityLiveRegion="polite" style={s.label}>Checking unfinished saves…</Text>:null}
  {pendingCheckError?<SharedNotice message={pendingCheckError} onRetry={()=>void checkPending()} busy={checkingPending}/>:null}
  {saveError?<SharedNotice message={saveError}/>:null}
  {pending?<View style={{gap:12}}><SharedNotice message={pending.command.operation==="create"&&pending.command.kind==="expense"?"Check your expense: "+pending.command.details.title+" · "+sharedMoney(pending.command.details.amountCents):pending.command.operation==="create"&&pending.command.kind==="repayment"?"Check your recorded repayment of "+sharedMoney(pending.command.details.amountCents):"A previous change still needs confirmation. Your attempted details are kept."}/><Button label="Check previous save" loading={working} disabled={!data||Boolean(error)||data.home.id!==pending.homeId} onPress={()=>void recover()}/></View>:null}
  {data?<>
   <View style={{flexDirection:"row",alignItems:"center",gap:16}}>
    <View style={{flex:1,gap:3}}><Text style={s.label}>{data.home.name}</Text>{!inline?<Text style={s.heading}>Everyone’s share, clear.</Text>:null}</View>
    <QuietAction label="People & invites" onPress={()=>router.push("/shared/people")}/>
   </View>
   {stage==="start"?<SharedStartCard ready={ready} hasEntries={data.entries.length>0} onAdd={()=>router.push("/shared/edit")}/>:<SharedBalances data={data} ready={ready} onSelect={pair=>router.push({pathname:"/shared/repay",params:{from:pair.from,to:pair.to}})}/>}
   {!inline&&stage!=="start"?<Button label="Add shared expense" variant="secondary" disabled={!ready} onPress={()=>router.push("/shared/edit")}/>:null}
   {data.entries.length?<View>
    <Text accessibilityRole="header" style={[typography.section,{color:colors.foreground,marginBottom:8}]}>Activity</Text>
    {data.entries.map(entry=><BriefRow key={entry.id} title={(entry.voided?"Removed · ":"")+(entry.kind==="expense"?entry.details.title:"Repayment")} value={sharedMoney(entry.details.amountCents)} detail={sharedDate(entry.details.happenedOn)+" · "+sharedEntryContext(entry,data.people,sharedMoney)} onPress={()=>router.push({pathname:"/shared/[id]",params:{id:entry.id}})}/>)}
    {data.nextCursor?<QuietAction label={moreBusy?"Loading…":"Load earlier entries"} disabled={moreBusy} onPress={()=>void more()}/>:null}
   </View>:null}
   <QuietAction label={busy?"Refreshing…":"Refresh balances"} onPress={()=>{if(!busy)void load();}}/>
   <Text style={s.label}>Shared entries are visible to everyone who joins this household. Your original bills and documents remain private.</Text>
  </>:null}
 </SharedFrame>;
}
