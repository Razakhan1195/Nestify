import {useLocalSearchParams,useRouter} from "expo-router";
import {useRef,useState} from "react";
import {Alert,Text,View} from "react-native";
import {Button} from "@/components/Button";
import {TextField} from "@/components/TextField";
import {QuietAction} from "@/components/Brief";
import {Surface} from "@/components/ui/Surface";
import {SharedFrame,SharedLoading,SharedNotice,sharedStyles as s,useSharedLedger} from "@/components/SharedExpenseUI";
import {saveSharedExpense,sharedDate,sharedPersonName,type ExpenseDetails,type RepaymentDetails} from "@/lib/shared-expenses";
import {sharedMoney} from "@/lib/shared-expense-math";
import {colors,typography} from "@/theme/tokens";
import {ApiError} from "@/lib/api";
export default function SharedExpenseDetail(){
 const {id,existing,saved}=useLocalSearchParams<{id:string;existing?:string;saved?:string}>(),router=useRouter(),{data,error,busy,load}=useSharedLedger(id);
 const [removing,setRemoving]=useState(false),[reason,setReason]=useState(""),[saving,setSaving]=useState(false),[failure,setFailure]=useState<string|null>(null),[history,setHistory]=useState(false);
 const lock=useRef(false),entry=data?.entries[0];
 const name=(id:string)=>sharedPersonName(data?.people??[],id);
 async function remove(){
  if(!entry||!data||lock.current||!reason.trim())return;lock.current=true;setSaving(true);setFailure(null);
  try{await saveSharedExpense(data.home.id,{operation:"void",id:entry.id,version:entry.version,reason:reason.trim()});setRemoving(false);await load();}
  catch(e){setFailure(e instanceof ApiError?e.message:"Could not confirm this change. Check Shared expenses before retrying.");}
  finally{setSaving(false);lock.current=false;}
 }
 return <SharedFrame title={entry?.kind==="repayment"?"Repayment":"Shared expense"} disabled={saving}>
  {error?<SharedNotice message={error} onRetry={()=>void load()}/>:null}
  {failure?<SharedNotice message={failure}/>:null}
  {busy&&!data?<SharedLoading/>:null}
  {entry&&data?<>
   {saved==="1"&&!entry.voided?<Text accessibilityLiveRegion="polite" style={[s.label,{color:colors.successForeground,fontWeight:"600"}]}>{entry.kind==="repayment"?"Repayment recorded. Your household balances are updated.":"Expense saved. Your household balances are updated."}</Text>:null}
   {existing==="1"?<Text accessibilityLiveRegion="polite" style={s.label}>This bill was already shared. You’re viewing the existing expense.</Text>:null}
   <Surface tone="subtle" style={{gap:12}}>
    <Text style={s.label}>{data.home.name} · {entry.voided?"Removed from balances":"Recorded in CAD"}</Text>
    <Text accessibilityRole="header" style={s.heading}>{entry.kind==="expense"?entry.details.title:"Repayment recorded"}</Text>
    <Text style={[typography.display,{color:colors.foreground,fontVariant:["tabular-nums"]}]}>{sharedMoney(entry.details.amountCents)}</Text>
    <Text style={s.body}>{entry.kind==="expense"?"Paid by "+name(entry.details.paidBy):name(entry.details.from)+" → "+name(entry.details.to)}</Text>
    <Text style={s.label}>{sharedDate(entry.details.happenedOn)}</Text>
   </Surface>
   {entry.kind==="expense"?<View>
    <Text accessibilityRole="header" style={[typography.section,{color:colors.foreground}]}>Shares</Text>
    {entry.details.shares.map(share=><View key={share.personId} style={[s.row,{flexDirection:"row",gap:16}]}><View style={{flex:1}}><Text style={s.body}>{name(share.personId)}</Text>{data.people.find(p=>p.id===share.personId)?.state==="former"?<Text style={s.label}>Former participant · history retained</Text>:null}</View><Text style={s.body}>{sharedMoney(share.cents)}</Text></View>)}
   </View>:<Text style={s.label}>This records a payment made outside Rezlee. It does not transfer or independently verify money.</Text>}
   {saved==="1"&&!entry.voided&&data.role==="owner"&&entry.kind==="expense"&&data.people.some(person=>person.guest&&person.state==="local"&&entry.details.shares.some(share=>share.personId===person.id))?<View style={{gap:6}}><Text style={s.label}>Your expense is saved even if someone hasn’t joined.</Text><QuietAction label="Invite them to join Rezlee" onPress={()=>router.push("/shared/people")}/></View>:null}
   {entry.details.note?<View style={{gap:6}}><Text style={s.label}>Note</Text><Text style={s.body}>{entry.details.note}</Text></View>:null}
   {entry.canEdit&&!error&&!busy&&!removing?<View style={{gap:12}}>
    {entry.kind==="expense"?<Button label="Correct expense" variant="secondary" onPress={()=>router.push({pathname:"/shared/edit",params:{id:entry.id}})}/>:null}
    <QuietAction label={entry.kind==="expense"?"Remove expense":"Remove repayment"} onPress={()=>setRemoving(true)}/>
   </View>:null}
   {removing?<Surface style={{gap:14}}>
    <Text style={s.heading}>Keep a record of the correction</Text><Text style={s.body}>This entry will stop affecting balances. Its history stays visible. Other expenses and repayments stay unchanged.</Text>
    <TextField label="Reason" value={reason} onChangeText={setReason} maxLength={240} editable={!saving} placeholder="Duplicate, entered incorrectly, refunded…"/>
    <Button label="Remove from balances" loading={saving} disabled={!reason.trim()} onPress={()=>Alert.alert("Remove this entry?","Recorded balances will be recalculated. This does not refund or move money.",[{text:"Keep",style:"cancel"},{text:"Remove",style:"destructive",onPress:()=>void remove()}])}/>
    <QuietAction label="Cancel" onPress={()=>{if(!saving)setRemoving(false);}}/>
   </Surface>:null}
   <View style={{gap:8}}>
    <QuietAction label={history?"Hide history":"View change history"} onPress={()=>setHistory(v=>!v)}/>
    {history?data.changes.map(change=>{
     const d=change.details,removed="reason" in d,record=removed?d.previous:d as ExpenseDetails|RepaymentDetails;
     return <View key={change.id} style={[s.row,{gap:6}]}>
      <Text style={s.body}>{change.action==="added"?"Added":change.action==="corrected"?"Corrected":"Removed"} by {change.actor_name}</Text>
      <Text style={s.label}>{new Date(change.created_at).toLocaleString("en-CA")} · Version {change.version}</Text>
      {removed?<Text style={s.body}>{d.reason}</Text>:null}
      <Text style={s.body}>{sharedMoney(record.amountCents)} · {"paidBy" in record?"Paid by "+name(record.paidBy):name(record.from)+" → "+name(record.to)}</Text>
      {"shares" in record?record.shares.map(share=><Text key={share.personId} style={s.label}>{name(share.personId)} · {sharedMoney(share.cents)}</Text>):null}
      {record.note?<Text style={s.label}>{record.note}</Text>:null}
     </View>;
    }):null}
    {history&&data.moreChanges?<Text style={s.label}>Showing the latest 20 changes.</Text>:null}
   </View>
   <QuietAction label="View balances" onPress={()=>router.replace("/shared")}/>
  </>:null}
 </SharedFrame>;
}
