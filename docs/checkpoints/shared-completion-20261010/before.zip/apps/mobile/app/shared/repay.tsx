import {useLocalSearchParams,useNavigation,useRouter} from "expo-router";
import {usePreventRemove} from "expo-router/react-navigation";
import {useEffect,useRef,useState} from "react";
import {Alert,Text,View} from "react-native";
import {Button} from "@/components/Button";
import {DateField} from "@/components/DateField";
import {TextField} from "@/components/TextField";
import {Surface} from "@/components/ui/Surface";
import {SharedFrame,SharedLoading,SharedNotice,sharedStyles as s,useSharedLedger} from "@/components/SharedExpenseUI";
import {localToday,saveSharedExpense,sharedPersonName,type SharedPayload} from "@/lib/shared-expenses";
import {centsInput,parseCadCents,sharedMoney} from "@/lib/shared-expense-math";
import {ApiError} from "@/lib/api";

function Repayment({data,from,to}:{data:SharedPayload;from:string;to:string}){
 const router=useRouter(),navigation=useNavigation(),lock=useRef(false),pair=data.balances.find(b=>b.from===from&&b.to===to);
 const [amount,setAmount]=useState(pair?centsInput(pair.cents):""),[date,setDate]=useState(localToday()),[note,setNote]=useState(""),[error,setError]=useState<string|null>(null),[saving,setSaving]=useState(false),[saved,setSaved]=useState<string|null>(null);
 const cents=parseCadCents(amount),canRecord=data.role==="owner"||data.people.some(p=>p.self&&(p.id===from||p.id===to));
 const valid=Boolean(pair&&cents&&cents<=pair.cents&&date<=localToday()&&date>="2000-01-01"&&canRecord);
 usePreventRemove(!saved&&Boolean(note||saving||date!==localToday()||amount!==(pair?centsInput(pair.cents):"")),({data:action})=>{
  if(saving){Alert.alert("Recording repayment","Wait for the result before leaving.");return;}
  Alert.alert("Leave this repayment?","Unsaved changes will be discarded. Any interrupted save can be checked from Shared expenses.",[{text:"Keep editing",style:"cancel"},{text:"Leave",onPress:()=>navigation.dispatch(action.action)}]);
 });
 useEffect(()=>{if(saved)router.replace({pathname:"/shared/[id]",params:{id:saved}});},[saved,router]);
 async function save(){
  if(lock.current||!valid)return;lock.current=true;setSaving(true);setError(null);
  try{const r=await saveSharedExpense(data.home.id,{operation:"create",kind:"repayment",details:{from,to,amountCents:cents!,happenedOn:date,note:note.trim()}});setSaved(r.id!);}
  catch(e){setError(e instanceof ApiError?e.message:"Could not confirm this repayment. Your attempted save is kept in Shared expenses.");}
  finally{lock.current=false;setSaving(false);}
 }
 if(!pair||!canRecord)return <SharedNotice message={!pair?"There is no outstanding balance between these people. Return to Shared expenses to see the latest balances.":"You can record repayments you sent or received. The household owner can also record them."}/>;
 return <>
  <Surface tone="subtle" style={{gap:12}}>
   <Text style={s.label}>{data.home.name}</Text><Text style={s.heading}>{sharedPersonName(data.people,from)} → {sharedPersonName(data.people,to)}</Text>
   <Text style={s.body}>{sharedMoney(pair.cents)} outstanding</Text>
  </Surface>
  {error?<SharedNotice message={error}/>:null}
  <View pointerEvents={saving?"none":"auto"} style={{gap:20}}>
   <TextField label="Amount repaid (CAD)" value={amount} onChangeText={setAmount} keyboardType="decimal-pad" maxLength={12} editable={!saving}/>
   {cents&&cents>pair.cents?<Text style={s.label}>Use an amount up to {sharedMoney(pair.cents)}. You can record a partial repayment.</Text>:null}
   <DateField label="Payment date" value={date} onChange={setDate}/>
   <TextField label="Note (optional)" value={note} onChangeText={setNote} maxLength={500} editable={!saving} placeholder="Interac e-Transfer, cash…"/>
  </View>
  <Button label="Record repayment" loading={saving} disabled={!valid} onPress={()=>Alert.alert("Already repaid?","Record "+sharedMoney(cents??0)+" from "+sharedPersonName(data.people,from)+" to "+sharedPersonName(data.people,to)+". Rezlee will update the ledger without moving money.",[{text:"Cancel",style:"cancel"},{text:"Record",onPress:()=>void save()}])}/>
  <Text style={s.label}>Only record money already sent or received. This is a shared record, not a payment confirmation from your bank.</Text>
 </>;
}
export default function RecordRepayment(){
 const {from="",to=""}=useLocalSearchParams<{from:string;to:string}>(),{data,error,busy,load}=useSharedLedger();
 return <SharedFrame title="Record repayment">
  {error?<SharedNotice message={error} onRetry={()=>void load()}/>:null}{busy&&!data?<SharedLoading/>:null}
  {data&&!error?<Repayment key={data.home.id+from+to} data={data} from={from} to={to}/>:null}
 </SharedFrame>;
}
