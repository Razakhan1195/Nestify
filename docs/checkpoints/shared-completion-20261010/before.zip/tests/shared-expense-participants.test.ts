import test from "node:test";
import assert from "node:assert/strict";
import {initialExpenseParticipants,hasSharedParticipants} from "../apps/mobile/src/lib/shared-expense-participants";
const people=[{id:"me",self:true,state:"owner"},{id:"alex",self:false,state:"local"},{id:"sam",self:false,state:"member"}];
test("new expenses never silently select other household participants",()=>{
 assert.deepEqual(initialExpenseParticipants(people),["me"]);
 assert.deepEqual(initialExpenseParticipants(people.slice(1)),[]);
});
test("shared expense needs another real participant and valid unique selections",()=>{
 assert.equal(hasSharedParticipants(people,["me"],"me"),false);
 assert.equal(hasSharedParticipants(people,[],"me"),false);
 assert.equal(hasSharedParticipants(people,["me","alex"],"me"),true);
 assert.equal(hasSharedParticipants(people,["alex"],"me"),true);
 assert.equal(hasSharedParticipants(people,["alex"],"alex"),false);
 assert.equal(hasSharedParticipants(people,["me","unknown"],"me"),false);
 assert.equal(hasSharedParticipants(people,["me","alex","alex"],"me"),false);
 assert.equal(hasSharedParticipants(people,["me","alex"],"unknown"),false);
});
