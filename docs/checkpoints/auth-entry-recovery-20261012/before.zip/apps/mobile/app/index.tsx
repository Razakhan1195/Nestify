import { readIncomingPhoneInvite } from "@/lib/phone-invites";
import { setupDrafts } from "@/lib/onboarding-draft";
import { shouldResumeSetup } from "@/lib/onboarding-draft-core";
import { readDeletionReceipt } from "@/lib/account-deletion";
import { Redirect } from "expo-router";
import { useEffect, useState } from "react";
import { Pressable, Text, View } from "react-native";

import { RezleeLoading } from "@/components/RezleeLoading";
import { useAuth } from "@/auth/AuthProvider";
import { ApiError } from "@/lib/api";
import { fetchOnboarding } from "@/lib/onboarding-data";
import { colors, spacing, typography } from "@/theme/tokens";

type Destination = "/onboarding" | "/(tabs)/home" | "/delete-account" | "/household/join" | null;

export default function Index() {
  const { session, isLoading: authLoading } = useAuth();
  const [destination, setDestination] = useState<Destination>(null);
  const [error, setError] = useState<string | null>(null);
  const [attempt, setAttempt] = useState(0);
  const [receiptChecked, setReceiptChecked] = useState(false);
  useEffect(() => {
    if (authLoading) return;
    let active = true;
    void readDeletionReceipt().then(receipt => {
      if (active && receipt && (!session || receipt.userId === session.user.id)) setDestination("/delete-account");
    }).catch(() => { if (active) setError("Your saved deletion status couldn’t be read."); })
      .finally(() => { if (active) setReceiptChecked(true); });
    return () => { active = false; };
  }, [authLoading, session]);

  useEffect(() => {
    if (authLoading || !session || !receiptChecked || destination !== null) return;
    let active = true;
    readIncomingPhoneInvite().then(token => token ? null : fetchOnboarding())
      .then(async (payload) => {
        if (!payload) { if (active) setDestination("/household/join"); return; }
        // A draft read failure must not block an existing household from Home.
        const draft = await setupDrafts.read(session.user.id).catch(() => null);
        if (active) setDestination(!payload.home || shouldResumeSetup(draft, payload.home.id, payload.accessRole) ? "/onboarding" : "/(tabs)/home");
      })
      .catch((loadError) => {
        if (!active) return;
        setError(
          loadError instanceof ApiError
            ? loadError.message
            : "We could not load your Rezlee setup.",
        );
      });

    return () => {
      active = false;
    };
  }, [authLoading, session, attempt, receiptChecked, destination]);

  if (authLoading || !receiptChecked) {
    return <LoadingScreen />;
  }

  if (destination === "/delete-account") return <Redirect href="/delete-account" />;

  if (!session) {
    return <Redirect href="/(auth)/welcome" />;
  }

  if (destination) {
    return <Redirect href={destination} />;
  }
  if (error) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.background, alignItems: "center", justifyContent: "center", padding: spacing["2xl"], gap: spacing.md }}>
        <Text style={[typography.title, { color: colors.foreground, textAlign: "center" }]}>Could not load Rezlee</Text>
        <Text style={[typography.body, { color: colors.mutedForeground, textAlign: "center" }]}>{error}</Text>
        <Pressable onPress={() => { setError(null); setAttempt((value) => value + 1); }} style={{ minHeight: 44, justifyContent: "center" }}>
          <Text style={{ fontSize: 14, fontWeight: "600", color: colors.primary }}>Try again</Text>
        </Pressable>
      </View>
    );
  }

  return <LoadingScreen />;
}

function LoadingScreen() {
  return (
    <View style={{ flex: 1, alignItems: "center", justifyContent: "center", backgroundColor: colors.background }}>
      <RezleeLoading />
    </View>
  );
}
