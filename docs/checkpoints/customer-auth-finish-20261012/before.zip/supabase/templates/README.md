# Rezlee authentication email templates

Prepared 2026-09-25. These source files do not configure hosted Supabase automatically.

- Confirm signup: confirmation.html; subject: Confirm your email for Rezlee.
- Password recovery: recovery.html; subject: Reset your Rezlee password.
- Keep the existing `{{ .ConfirmationURL }}` token and configured redirect flow intact.
- No tracking pixels, externally fetched graphics, promotional content or interpolated user metadata.
- Sender display name: Rezlee. Use the verified Rezlee sending address in the existing Resend account; do not invent or use an unverified From address.
- Configure custom SMTP on the intended Supabase project using provider credentials through its protected settings. Do not put passwords in this directory, mobile code or logs.
- Do not change the magic-link/OTP template or enable email-code recovery gates as part of this change.

Acceptance before release: send to an explicitly authorized test inbox; inspect actual From and branding, SPF/DKIM/DMARC delivery results, confirmation and reset links, expired/resend behavior and native return. A template render or admin-confirmed test account is not delivery verification. Keep production separate from staging and preserve previous settings for rollback.

References checked: https://supabase.com/docs/guides/auth/auth-smtp and https://supabase.com/docs/guides/auth/auth-email-templates .

## Hosted staging status — 2026-09-25
Confirmation/recovery templates and custom Resend SMTP are now configured on staging gjwvalpxnfbvryosmcbj and verified by management API read-back. Production unchanged. SMTP credential acceptance succeeded; no messages sent and inbox/link journeys remain unverified. See docs/staging-auth-email-verification-2026-09-25.json.
