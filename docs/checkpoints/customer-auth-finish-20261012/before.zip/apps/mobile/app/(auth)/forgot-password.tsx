import { useAuth } from "@/auth/AuthProvider";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useEffect, useState, useSyncExternalStore } from "react";
import { KeyboardAvoidingView, Platform, Pressable, ScrollView, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { passwordRecovery } from "@/auth/recovery-client";
import { Button } from "@/components/Button";
import { ScreenNavigation } from "@/components/ScreenNavigation";
import { TextField } from "@/components/TextField";
import { colors, spacing, typography } from "@/theme/tokens";

export default function ForgotPasswordScreen() {
  const router = useRouter();
  const { session } = useAuth();
  const params = useLocalSearchParams<{ email?: string }>();
  const [email, setEmail] = useState(typeof params.email === "string" ? params.email : "");
  const recovery = useSyncExternalStore(passwordRecovery.subscribe, passwordRecovery.snapshot, passwordRecovery.snapshot);
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => { void passwordRecovery.resume(); }, []);
  useEffect(() => {
    if (recovery.retryAt <= Date.now()) return;
    const timer = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(timer);
  }, [recovery.retryAt]);
  const waiting = Math.max(0, Math.ceil((recovery.retryAt - now) / 1000));
  const busy = ["sending", "verifying", "saving"].includes(recovery.phase);
  const sent = recovery.phase === "sent";
  const resumable = ["ready", "success", "uncertain"].includes(recovery.phase);
  return <SafeAreaView edges={["left", "right", "bottom"]} style={{ flex: 1, backgroundColor: colors.background }}>
    <ScreenNavigation title="Password help" fallback={session ? "/app-security" : "/(auth)/login"} />
    <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} style={{ flex: 1 }}>
      <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={{ padding: spacing["2xl"], gap: spacing.xl }}>
        <View style={{ gap: spacing.sm }}>
          <Text accessibilityRole="header" style={[typography.heading, { color: colors.foreground }]}>{sent ? "Check your email" : "Reset your password"}</Text>
          <Text style={[typography.body, { color: colors.mutedForeground }]}>{sent
            ? `If an account exists for ${recovery.email}, a reset link is on the way. Check your junk folder too.`
            : "Enter the email you use for Rezlee. We’ll send a link to choose a new password."}</Text>
          <Text style={[typography.body, { color: colors.mutedForeground }]}>Open the latest link on this phone within 20 minutes. You can leave the app while you check your email.</Text>
        </View>
        {recovery.error ? <Text accessibilityRole="alert" style={[typography.body, { color: colors.criticalForeground }]}>{recovery.error}</Text> : null}
        {resumable ? <Button label="Continue password recovery" onPress={() => router.push("/reset-password")} /> : <>
          <TextField label="Email" autoCapitalize="none" autoComplete="email" keyboardType="email-address" autoCorrect={false} value={email} editable={!busy} onChangeText={setEmail} maxLength={254} />
          <Button label={waiting ? `Send another link in ${waiting}s` : sent ? "Send another link" : "Send reset link"} loading={busy} disabled={!email.trim() || waiting > 0} onPress={() => void passwordRecovery.request(email)} />
          {sent ? <Text style={[typography.caption, { color: colors.mutedForeground }]}>Wrong email? Edit it above, then request a new link. A new request replaces the previous link.</Text> : null}
        </>}
        <Pressable accessibilityRole="button" onPress={() => session ? router.back() : router.replace("/(auth)/login")} style={{ minHeight: 44, justifyContent: "center" }}>
          <Text style={[typography.body, { color: colors.primary }]}>{session ? "Back to Security" : "Back to sign in"}</Text>
        </Pressable>
      </ScrollView>
    </KeyboardAvoidingView>
  </SafeAreaView>;
}
