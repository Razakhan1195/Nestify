import { HomeBrief } from "@/components/HomeBrief";
import { billAccountOverview } from "@/lib/bill-account-overview";
import { HomeUtilityProgress } from "@/components/HomeUtilityProgress";
import { HomeSharedExpenses } from "@/components/HomeSharedExpenses";
import { RecallWatchSummary } from "@/components/RecallWatchSummary";
import { Feather } from "@expo/vector-icons";
import { Redirect, useFocusEffect, useLocalSearchParams, useRouter } from "expo-router";
import { useCallback, useEffect, useRef, useState } from "react";
import { ActivityIndicator, Pressable, RefreshControl, ScrollView, Text, View, useWindowDimensions } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { BriefRow, ReadNotice } from "@/components/Brief";
import { HomeQuickActions, SectionHeading, HomeGreeting, HomeSection } from "@/components/WorkspaceUI";
import { HomeStartJourney } from "@/components/HomeStartJourney";
import { HomeBillBrief } from "@/components/BillAccountBrief";
import { homeOverviewState, homeUpcomingHref, homeUpcomingItems } from "@/lib/home-overview";
import { historyDate } from "@/lib/manual-history-insights";
import { isStartingGoal, localDay, startingContent, type StartingGoal } from "@/lib/home-start";
import { fetchVault, formatVaultDate, type VaultDocument } from "@/lib/vault-data";
import { fetchCare } from "@/lib/care-data";
import { HomeAssistantTile } from "@/components/HomeAssistantTile";
import { homeTaskStates, remainingHomeTasks, type HomeTaskStates } from "@/lib/home-task-state";
import { fetchBills, type BillsPayload } from "@/lib/bills-data";
import { fetchHome, type HomePayload } from "@/lib/home-data";
import { subscribeHomeTabPress } from "@/lib/tab-events";
import { colors, homeTile, layout, typography } from "@/theme/tokens";

export default function HomeScreen() {
  const router = useRouter();
  const { width } = useWindowDimensions();
  const { begin } = useLocalSearchParams<{ begin?: string }>();
  const beginHandled = useRef<string | null>(null);
  const [itemCount,setItemCount]=useState(0);
  const [recentRecords, setRecentRecords] = useState<VaultDocument[]>([]);
  const dataScope = useRef<string | null>(null);
  const [taskStates, setTaskStates] = useState<HomeTaskStates | null>(null);
  const [taskReadError, setTaskReadError] = useState(false);
  const scroll = useRef<ScrollView>(null);
  const request = useRef(0);
  const [payload, setPayload] = useState<HomePayload | null>(null);
  const [bills, setBills] = useState<BillsPayload | null>(null);
  const [insightError, setInsightError] = useState(false);
  const [error, setError] = useState(false);
  const [busy, setBusy] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const load = useCallback(async (pull = false) => {
    const version = ++request.current;
    setBusy(true);
    if (pull) setRefreshing(true);
    try {
      const next = await fetchHome();
      if (version !== request.current) return;
      const scope = next.needsOnboarding ? "onboarding" : `${next.home.id}:${next.accessRole}`;
      if (scope !== dataScope.current) {
        dataScope.current = scope; setBills(null); setRecentRecords([]); setItemCount(0); setTaskStates(null);
      }
      setPayload(next); setError(false);
      if (!next.needsOnboarding && next.accessRole === "owner") {
        const [billResult, vaultResult, careResult] = await Promise.allSettled([fetchBills(), fetchVault(), fetchCare()]);
        if (version !== request.current) return;
        const sources = {
          bills: billResult.status === "fulfilled" ? billResult.value : null,
          vault: vaultResult.status === "fulfilled" ? vaultResult.value : null,
          care: careResult.status === "fulfilled" ? careResult.value : null,
        };
        if (sources.bills && !sources.bills.needsOnboarding) { setBills(sources.bills); setInsightError(false); }
        else setInsightError(true);
        const states = homeTaskStates(sources);
        setTaskStates(previous => previous ? { bills: states.bills === "unknown" ? previous.bills === "saved" ? "saved" : "unknown" : states.bills, records: states.records === "unknown" ? previous.records === "saved" ? "saved" : "unknown" : states.records, care: states.care === "unknown" ? previous.care === "saved" ? "saved" : "unknown" : states.care } : states);
        setTaskReadError(states.records === "unknown" || states.care === "unknown");
        if (sources.vault && !sources.vault.needsOnboarding) {
          setItemCount(sources.vault.items.length);
          setRecentRecords(sources.vault.documents.filter(record=>record.document_type!=="Statement").sort((a, b) => b.created_at.localeCompare(a.created_at) || a.id.localeCompare(b.id)).slice(0, 2));
        }
      } else { setBills(null); setInsightError(false); setRecentRecords([]); setTaskStates(null); setTaskReadError(false); }
    }
    catch { if (version === request.current) setError(true); }
    finally { if (version === request.current) { setBusy(false); setRefreshing(false); } }
  }, []);
  useFocusEffect(useCallback(() => { void load(); return () => { request.current++; setRefreshing(false); }; }, [load]));
  useEffect(() => subscribeHomeTabPress(() => scroll.current?.scrollTo({ y: 0, animated: true })), []);
  useEffect(() => {
    if (!begin) { beginHandled.current = null; return; }
    if (!isStartingGoal(begin) || !payload || payload.needsOnboarding || payload.accessRole !== "owner" || beginHandled.current === begin) return;
    beginHandled.current = begin;
    router.setParams({ begin: "" });
    router.push(startingContent[begin].route as never);
  }, [begin, payload, router]);
  function startTask(goal: StartingGoal) {
    if (!payload || payload.needsOnboarding || payload.accessRole !== "owner") return;
    router.push(startingContent[goal].route as never);
  }
  if (payload?.needsOnboarding) return <Redirect href="/onboarding" />;
  const home = payload && !payload.needsOnboarding ? payload : null;
  const owner = home?.accessRole === "owner";
  const utilityData = bills && !bills.needsOnboarding ? bills : null;
  const state = home ? homeOverviewState(home, taskStates, error || taskReadError || insightError) : null;
  const remaining = taskStates && !error ? remainingHomeTasks(taskStates) : [];
  const upcoming = home ? homeUpcomingItems(home) : [];
  const providerActivity = utilityData?.providerActivity.filter(item => !home?.attentionItems.slice(0, 2).some(attention => attention.sourceType === "provider" && attention.providerId === item.providerId)) ?? [];
  return <SafeAreaView edges={["left", "right"]} style={{ flex: 1, backgroundColor: colors.canvas }}>
    <ScrollView ref={scroll} contentInsetAdjustmentBehavior="never" automaticallyAdjustContentInsets={false}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => void load(true)} tintColor={colors.primary} />}
      contentContainerStyle={{ padding: layout.screenHorizontal, paddingHorizontal: width < 360 ? 16 : layout.screenHorizontal, paddingTop: layout.screenTop, paddingBottom: 32, gap: layout.sectionGap }}>
      <View style={{gap:16}}>
        <HomeGreeting household={home ? home.home.nickname || "Your household" : undefined} />
        {owner ? <HomeQuickActions onBill={() => startTask("bills")} onRecord={() => startTask("records")} onReminder={() => startTask("care")} onSplit={() => router.push("/shared/edit")} /> : null}
      </View>
      {!home ? <>{busy ? <ActivityIndicator accessibilityLabel="Loading your home" color={colors.primary} /> : <ReadNotice message="Your home couldn’t be loaded." onRetry={() => void load()} />}</> : <>
        {error || home.availability?.missing.length ? <ReadNotice message={error ? "We couldn’t check for updates. Showing the last loaded information." : "Some information is unavailable. Your household summary may be incomplete."} busy={busy} onRetry={() => void load()} /> : null}
        <HomeBrief home={home} accounts={utilityData ? billAccountOverview(utilityData,localDay(),!insightError&&!error) : []} failed={error||taskReadError||insightError} loading={busy} providerBusy={providerActivity.some(item=>item.state==="syncing")} />
        {owner ? <HomeUtilityProgress key={"utility-progress:" + home.home.id} hasAccounts={Boolean(utilityData?.utilityInsights.length) && !insightError} onComplete={() => void load()} /> : null}
        {owner && providerActivity.length ? <View>
          {providerActivity.slice(0, 2).map(item => <BriefRow key={item.providerId} title={`${item.providerName} · ${item.state === "syncing" ? "Updating" : "Connection needs attention"}`} detail={item.message} onPress={() => router.push(item.mobileHref as never)} />)}
          {providerActivity.length > 2 ? <BriefRow title={`Review all ${providerActivity.length} connection updates`} onPress={() => router.push("/provider")} /> : null}
        </View> : null}
        {upcoming.length ? <HomeSection><SectionHeading title="Coming up" />
          {upcoming.slice(0, 3).map(item => {
            const date = historyDate(item.date) ? new Date(item.date + "T12:00:00Z") : null;
            return <Pressable key={item.id} accessibilityRole="button" accessibilityLabel={`${item.title}. ${item.detail}. ${item.timing}`} onPress={() => router.push(homeUpcomingHref(item) as never)} style={({ pressed }) => ({ paddingVertical: 15, borderBottomWidth: 1, borderBottomColor: colors.border, backgroundColor: pressed ? colors.surfaceSubtle : "transparent", flexDirection: "row", alignItems: "center", gap: 12 })}>
              <View accessible={false} style={{ minWidth: 46, borderRadius: 10, padding: 7, backgroundColor: colors.surfaceSubtle, alignItems: "center", gap: 2 }}>
                {date ? <><Text style={[typography.caption, { color: colors.mutedForeground }]}>{new Intl.DateTimeFormat("en-CA", { month: "short", timeZone: "UTC" }).format(date).toUpperCase()}</Text><Text style={[typography.title, { color: colors.foreground }]}>{date.getUTCDate()}</Text></> : <Feather name="calendar" size={23} color={colors.primary} />}
              </View>
              <View style={{ flex: 1, gap: 4 }}><Text style={[typography.body, { fontWeight: "600", color: colors.foreground }]}>{item.title}</Text><Text style={[typography.meta, { color: colors.mutedForeground }]}>{item.type === "Vault" ? "Record" : item.type} · {item.detail} · {item.timing}</Text></View><Feather name="chevron-right" size={17} color={colors.primary} />
            </Pressable>;
          })}
        </HomeSection> : null}
        {owner && insightError ? <ReadNotice message={utilityData ? "Couldn’t check for newer bills. Showing previously loaded records." : "Your bill information couldn’t be loaded."} busy={busy} onRetry={() => void load()} /> : null}
        {owner && utilityData ? <HomeBillBrief bills={utilityData} fresh={!insightError && !error} showChange={false} /> : null}
        <View style={{gap:homeTile.groupGap}}>
          <HomeSharedExpenses key={home.home.id + home.accessRole} homeId={home.home.id} />
        {owner && remaining.length && state?.showTaskTiles ? <HomeStartJourney remaining={remaining} onStart={startTask} /> : null}
        </View>
        {taskReadError ? <ReadNotice message="Some records or care tasks couldn’t be checked. Previously loaded items may be out of date." busy={busy} onRetry={() => void load()} /> : null}
        {owner && itemCount>0 ? <RecallWatchSummary key={"recall-watch:" + home.home.id} itemCount={itemCount} onlyActionable/>:null}
        {owner && recentRecords.length ? <HomeSection><SectionHeading title="Recently saved" />
          {recentRecords.map(record => <BriefRow key={record.id} title={record.title} detail={`${record.category}${record.expires_on ? ` · Expiry ${formatVaultDate(record.expires_on)}` : ""}`} onPress={() => router.push({ pathname: "/vault-record", params: { id: record.id } })} />)}
        </HomeSection> : null}
        {owner && busy && !taskStates ? <ActivityIndicator accessibilityLabel="Checking your saved bills, records and care tasks" color={colors.primary} /> : null}
        {owner && remaining.length && !state?.showTaskTiles && !state?.partial ? <View>
          {remaining.map(goal => <BriefRow key={goal} title={startingContent[goal].alternative} detail={startingContent[goal].alternativeDetail} onPress={() => startTask(goal)} />)}
        </View> : null}
        {!owner && home.dashboardState === "EMPTY" ? <View><Text style={[typography.section, { color: colors.foreground }]}>Your shared household</Text><BriefRow title="Open shared Care" detail="Shared tasks and reminders live here." onPress={() => router.push("/(tabs)/care")} /></View> : null}
        {state?.verifiedEmpty || (!owner && home.dashboardState === "EMPTY") ? <HomeAssistantTile owner={Boolean(owner)} /> : null}
      </>}
    </ScrollView>
  </SafeAreaView>;
}
